package com.subtleunlock.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Draws one wallpaper picture blended between LOCK, HOME and APP-DRAWER looks, plus independent
 * launcher app-depth and horizontal desktop-page parallax signals.
 *
 * Design (unchanged from v1.3 where it matters):
 *  - The picture is decoded ONCE at exactly the size needed to cover the screen plus every margin the
 *    current settings can need (slide reach, tilt, zoom-out headroom). Nothing is decoded while animating.
 *  - Margins come from the settings, so no edge can ever become visible.
 *  - With every new effect at zero, draw() takes the same single-bitmap path as v1.3, and the plain
 *    HOME look is drawn at base scale with an integer position (the original pixels).
 *  - draw() reuses one Matrix, one Paint, one Path: no allocations per frame.
 *
 * New in v1.4 (all cached, none computed per frame):
 *  - Grayscale: a colour-matrix filter on the Paint (GPU), updated in place.
 *  - Blur: two small pre-blurred copies (half and full strength) built when the picture, size or blur
 *    settings change; a frame cross-fades between sharp -> half -> full. A few hundred KB, not a
 *    second full-size bitmap.
 *  - Frame: the picture is clipped to an inset rounded rectangle over a dark background.
 *  - Fade: darkening, as before.
 *
 * progress: 0 = LOCK look ... 1 = HOME look (springy easing may pass slightly beyond either end).
 * follow:   0..1, how deep the launcher currently is (app drawer / app open). Only used at HOME.
 */
class WallpaperRenderer(private val context: Context) {

    private var bitmap: Bitmap? = null
    private var loadedKey: String? = null
    private var secondBitmap: Bitmap? = null
    private var secondLoadedKey: String? = null
    private var secondBlur1: Bitmap? = null
    private var secondBlur2: Bitmap? = null
    private var secondBlurKey: String? = null
    private var sourceBitmapWidth = 0
    private var sourceBitmapHeight = 0
    private var bleedXpx = 0
    private var bleedYpx = 0

    private var blur1: Bitmap? = null
    private var blur2: Bitmap? = null
    private var blurKey: String? = null

    private var screenW = 0
    private var screenH = 0
    private var baseScale = 1f
    private var restTx = 0f
    private var restTy = 0f
    private var ux = 0f
    private var uy = 0f
    private var lockSlidePx = 0f
    private var homeSlidePx = 0f
    private var drawerSlidePx = 0f
    private var lockZoom = 0f
    private var homeZoom = 0f
    private var drawerZoom = 0f
    private var desktopParallaxPx = 0f
    private var lockTilt = 0f
    private var homeTilt = 0f
    private var drawerTilt = 0f
    private var lockDim = 0f
    private var homeDim = 0f
    private var drawerDim = 0f
    private var lockFade = 0f
    private var homeFade = 0f
    private var drawerFade = 0f
    private var lockGray = 0f
    private var homeGray = 0f
    private var drawerGray = 0f
    private var lockBlur = 0f
    private var homeBlur = 0f
    private var drawerBlur = 0f
    private var blurMaxPct = 0f
    private var lockInset = 0f
    private var homeInset = 0f
    private var drawerInset = 0f
    private var insetRef = 1f
    private var cornerPx = 0f
    private var kFloor = 1f

    private val matrix = Matrix()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val colorMatrix = ColorMatrix()
    /** One ready-made grayscale filter per 1/64 step, created on first use (ColorMatrixColorFilter cannot be modified). */
    private val grayFilters = arrayOfNulls<ColorMatrixColorFilter>(GRAY_STEPS + 1)
    private val framePath = Path()
    private val frameRect = RectF()

    val isReady: Boolean get() = bitmap != null

    /**
     * Prepares geometry (and decodes / blurs if needed) for a surface of [w] x [h] pixels.
     * Cheap when nothing relevant changed. May decode on the calling thread (never call while animating).
     * @param pxPerDp pixels per dp for this surface (the preview passes a scaled value)
     * @return true if something can be drawn
     */
    fun configure(w: Int, h: Int, s: MotionSettings, pxPerDp: Float): Boolean {
        if (w <= 0 || h <= 0) return false
        val lock = s.lock
        val home = s.home

        // Springy easing overshoots by ~13%; plan margins for 15%.
        val ovf = if (s.easing == Easing.SPRING) 1.15f else 1f
        // The value at any moment is home + (lock - home) * inv with inv in [1 - ovf, ovf].
        fun bound(a: Float, b: Float): Float {
            val big = max(a, b)
            val small = min(a, b)
            return if (ovf > 1f) big * ovf + small * (ovf - 1f) else big
        }

        val lockSlide = lock.slideDp * pxPerDp
        val homeSlide = home.slideDp * pxPerDp
        val dFollow = if (s.followLauncher) s.drawer.slideDp * pxPerDp else 0f
        val reach = max(bound(lockSlide, homeSlide), dFollow * ovf)
        val desktopParallaxReach = if (s.desktopParallaxEnabled) s.desktopParallaxStrengthDp * pxPerDp else 0f
        val reachX = reach * abs(s.direction.ux)
        val reachY = reach * abs(s.direction.uy)

        // Tilt: the picture must still cover the screen when rotated about its centre, and the slide
        // reach must be measured along the TILTED axes (a vertical slide also eats into the tilted width).
        val maxTiltDeg = max(bound(lock.tiltTenths / 10f, home.tiltTenths / 10f), s.drawer.tiltTenths / 10f * ovf)
        val rad = Math.toRadians(maxTiltDeg.toDouble())
        val cosA = cos(rad)
        val sinA = sin(rad)
        val rotW = w * cosA + h * sinA + 2.0 * (reachX * cosA + reachY * sinA)
        val rotH = w * sinA + h * cosA + 2.0 * (reachX * sinA + reachY * cosA)

        // Zoom-out headroom: the base picture is this much larger than needed, so scaling it down by
        // up to the same factor still covers everything.
        val zl = lock.zoomPercent / 100f
        val zh = home.zoomPercent / 100f
        val zd = if (s.followLauncher) s.drawer.zoomPercent / 100f else 0f
        var kMinRel = min(1f, min(1f + zl, min(1f + zh, 1f + zd)))
        // The spring easing can overshoot progress>1; with inv=1-progress that extends
        // away from the HOME/APP-DRAWER zoom. Reserve headroom for both endpoints.
        kMinRel = min(kMinRel, 1f + (zh + (zh - zl) * (ovf - 1f)))
        kMinRel = min(kMinRel, 1f + (zd + (zd - zl) * (ovf - 1f)))
        // Also retain the opposite-end bound for launchers/easings that report progress<0.
        kMinRel = min(kMinRel, 1f + (zh + (zl - zh) * ovf))
        kMinRel = min(kMinRel, 1f + (zd + (zl - zd) * ovf))
        val headroom = 1f / kMinRel

        // +2 px: spare pixels so the half-pixel rounding of the rest position can never expose an edge.
        // Decode using the original lock/home geometry. A narrow edge-bleed is prepared once for
        // desktop parallax, preserving the original image framing at offset=0 (including low-res photos).
        val baseAreaW = ceil((rotW + 2.0) * headroom).toInt()
        val areaW = baseAreaW
        val areaH = ceil((rotH + 2.0) * headroom).toInt()

        val key = s.wallpaperId + "|" + areaW + "x" + areaH + "|bleed=" + desktopParallaxReach + "|tilt=" + maxTiltDeg + "|headroom=" + headroom
        if (bitmap == null || key != loadedKey) {
            var decoded = decode(s.wallpaperId, areaW, areaH)
            if (decoded == null && s.wallpaperId != Wallpapers.DEFAULT_ID) {
                // Missing/corrupt custom image: fall back to the bundled default instead of a black screen.
                decoded = decode(Wallpapers.DEFAULT_ID, areaW, areaH)
            }
            if (decoded == null) return false
            sourceBitmapWidth = decoded.width
            sourceBitmapHeight = decoded.height
            val sourceScale = max(baseAreaW / decoded.width.toFloat(), areaH / decoded.height.toFloat())
            bleedXpx = if (desktopParallaxReach > 0f) ceil(desktopParallaxReach * headroom / sourceScale).toInt() + 5 else 0
            val verticalReach = desktopParallaxReach * abs(kotlin.math.tan(rad)).toFloat()
            bleedYpx = if (verticalReach > 0f) ceil(verticalReach * headroom / sourceScale).toInt() + 5 else 0
            bitmap = if (bleedXpx > 0 || bleedYpx > 0) addEdgeBleed(decoded, bleedXpx, bleedYpx) else decoded
            loadedKey = key // also set after a fallback, so a failing decode is not retried on every call
        }

        val bmp = bitmap ?: return false
        val secondId = s.secondWallpaperId
        val secondKey = secondId + "|" + areaW + "x" + areaH + "|" + sourceBitmapWidth + "x" + sourceBitmapHeight + "|" + bleedXpx + "x" + bleedYpx
        if (secondId.isBlank() || secondId == s.wallpaperId) {
            clearSecondBitmap()
        } else if (secondBitmap == null || secondLoadedKey != secondKey) {
            clearSecondBitmap()
            val decodedSecond = decode(secondId, areaW, areaH)
            secondBitmap = decodedSecond?.let { source ->
                val cropped = centerCrop(source, sourceBitmapWidth, sourceBitmapHeight)
                if (bleedXpx > 0 || bleedYpx > 0) addEdgeBleed(cropped, bleedXpx, bleedYpx) else cropped
            }
            secondLoadedKey = secondKey
        }
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        val originalW = sourceBitmapWidth.toFloat()
        val originalH = sourceBitmapHeight.toFloat()
        baseScale = max(baseAreaW / originalW, areaH / originalH)
        // Added edge bleed is centred around the original photo, so its resting transform is unchanged.
        restTx = ((w - originalW * baseScale) / 2f - bleedXpx * baseScale).roundToInt().toFloat()
        restTy = ((h - originalH * baseScale) / 2f - bleedYpx * baseScale).roundToInt().toFloat()

        screenW = w
        screenH = h
        ux = s.direction.ux
        uy = s.direction.uy
        lockSlidePx = lockSlide
        homeSlidePx = homeSlide
        drawerSlidePx = dFollow
        lockZoom = zl
        homeZoom = zh
        drawerZoom = zd
        desktopParallaxPx = desktopParallaxReach
        lockTilt = lock.tiltTenths / 10f
        homeTilt = home.tiltTenths / 10f
        drawerTilt = s.drawer.tiltTenths / 10f
        lockDim = lock.dimPercent / 100f
        homeDim = home.dimPercent / 100f
        drawerDim = s.drawer.dimPercent / 100f
        lockFade = lock.fadePercent / 100f
        homeFade = home.fadePercent / 100f
        drawerFade = s.drawer.fadePercent / 100f
        lockGray = lock.grayPercent / 100f
        homeGray = home.grayPercent / 100f
        drawerGray = s.drawer.grayPercent / 100f
        lockBlur = lock.blurPercent.toFloat()
        homeBlur = home.blurPercent.toFloat()
        drawerBlur = s.drawer.blurPercent.toFloat()
        lockInset = lock.insetDp * pxPerDp
        homeInset = home.insetDp * pxPerDp
        drawerInset = s.drawer.insetDp * pxPerDp
        insetRef = max(1f, max(lockInset, max(homeInset, drawerInset)))
        cornerPx = s.frameCornerDp * pxPerDp
        kFloor = 1f / headroom

        // Blur levels: rebuilt only when the picture, the screen width or the strongest blur changes.
        blurMaxPct = max(lockBlur, max(homeBlur, drawerBlur))
        if (blurMaxPct > 0f) {
            val bk = key + "|" + blurMaxPct.toInt() + "|" + w
            if (blur2 == null || bk != blurKey) {
                buildBlur(bmp, w, blurMaxPct)
                blurKey = bk
            }
        } else {
            blur1 = null
            blur2 = null
            blurKey = null
        }
        val second = secondBitmap
        if (second != null && blurMaxPct > 0f) {
            val secondBlurKeyNow = secondKey + "|" + blurMaxPct.toInt() + "|" + w
            if (secondBlur1 == null || secondBlur2 == null || secondBlurKey != secondBlurKeyNow) {
                try {
                    val fullPx = blurMaxPct / 100f * BLUR_MAX_PX * (w / 1080f)
                    secondBlur1 = BlurUtil.blur(second, max(2f, fullPx * 0.5f))
                    secondBlur2 = BlurUtil.blur(second, max(3f, fullPx))
                    secondBlurKey = secondBlurKeyNow
                } catch (_: Exception) {
                    secondBlur1 = null
                    secondBlur2 = null
                    secondBlurKey = null
                } catch (_: OutOfMemoryError) {
                    secondBlur1 = null
                    secondBlur2 = null
                    secondBlurKey = null
                }
            }
        } else {
            secondBlur1 = null
            secondBlur2 = null
            secondBlurKey = null
        }
        return true
    }

    /** Draws one frame. No allocations. See the class comment for [progress] and [follow]. */
    fun draw(canvas: Canvas, progress: Float, follow: Float, desktopOffset: Float = 0f) {
        val bmp = bitmap
        if (bmp == null) {
            canvas.drawColor(Color.BLACK)
            return
        }
        val inv = 1f - progress // 1 = LOCK look, 0 = HOME look

        val homeToDrawerZoom = mix(homeZoom, drawerZoom, follow)
        var k = baseScale * (1f + mix(homeToDrawerZoom, lockZoom, inv))
        val kMin = baseScale * kFloor
        if (k < kMin) k = kMin // can only trigger on overshoot; headroom already covers the settings

        val homeToDrawerSlide = homeSlidePx - drawerSlidePx * follow
        val slide = mix(homeToDrawerSlide, lockSlidePx, inv)
        // Launcher xOffset is normalized across desktop pages. Move the wallpaper in the
        // opposite direction by a small bounded amount; no sensor or per-frame inference.
        val pageShift = -desktopOffset.coerceIn(-1f, 1f) * desktopParallaxPx
        val tx = restTx + (bmp.width * baseScale - bmp.width * k) / 2f + ux * slide + pageShift
        val ty = restTy + (bmp.height * baseScale - bmp.height * k) / 2f + uy * slide
        val angle = mix(mix(homeTilt, drawerTilt, follow), lockTilt, inv)

        var dim = mix(mix(homeDim, drawerDim, follow), lockDim, inv)
        if (dim < 0f) dim = 0f
        var gray = mix(mix(homeGray, drawerGray, follow), lockGray, inv)
        gray = if (gray < 0f) 0f else if (gray > 1f) 1f else gray
        var inset = mix(mix(homeInset, drawerInset, follow), lockInset, inv)
        if (inset < 0f) inset = 0f

        val l1 = blur1
        val l2 = blur2
        var pos = 0f // 0 = sharp, 1 = half blur, 2 = full blur
        if (blurMaxPct > 0f && l1 != null && l2 != null) {
            val b = mix(mix(homeBlur, drawerBlur, follow), lockBlur, inv) / blurMaxPct
            pos = (if (b < 0f) 0f else if (b > 1f) 1f else b) * 2f
        }

        val framed = inset > 0.5f
        if (framed) {
            canvas.drawColor(FRAME_COLOR)
            canvas.save()
            framePath.reset()
            frameRect.set(inset, inset, screenW - inset, screenH - inset)
            val corner = cornerPx * min(1f, inset / insetRef)
            framePath.addRoundRect(frameRect, corner, corner, Path.Direction.CW)
            canvas.clipPath(framePath)
        }

        if (gray > 0.002f) {
            paint.colorFilter = grayFilterFor(gray)
        } else {
            paint.colorFilter = null
        }

        paint.alpha = 255
        if (pos <= 0.001f || l1 == null || l2 == null) {
            drawLayer(canvas, bmp, bmp, k, angle, tx, ty)
        } else {
            val idx = if (pos >= 2f) 2 else pos.toInt()
            val frac = pos - idx
            val first = if (idx == 0) bmp else if (idx == 1) l1 else l2
            drawLayer(canvas, first, bmp, k, angle, tx, ty)
            if (idx < 2 && frac > 0.004f) {
                paint.alpha = (frac * 255f).toInt()
                drawLayer(canvas, if (idx == 0) l1 else l2, bmp, k, angle, tx, ty)
                paint.alpha = 255
            }
        }

        // The optional second photo is pre-decoded and pre-blurred during configure(), never per frame.
        val second = secondBitmap
        val fade = mix(mix(homeFade, drawerFade, follow), lockFade, inv).coerceIn(0f, 1f)
        if (second != null && fade > 0.001f) {
            val alpha = (fade * 255f).toInt().coerceIn(0, 255)
            if (pos <= 0.001f || l1 == null || l2 == null || secondBlur1 == null || secondBlur2 == null) {
                paint.alpha = alpha
                drawLayer(canvas, second, bmp, k, angle, tx, ty)
            } else {
                val idx = if (pos >= 2f) 2 else pos.toInt()
                val frac = pos - idx
                val firstSecond = if (idx == 0) second else if (idx == 1) secondBlur1!! else secondBlur2!!
                paint.alpha = alpha
                drawLayer(canvas, firstSecond, bmp, k, angle, tx, ty)
                if (idx < 2 && frac > 0.004f) {
                    paint.alpha = (alpha * frac).toInt()
                    drawLayer(canvas, if (idx == 0) secondBlur1!! else secondBlur2!!, bmp, k, angle, tx, ty)
                }
            }
            paint.alpha = 255
        }
        if (dim > 0f) {
            val a = (dim * 255f).toInt().coerceIn(0, 255)
            canvas.drawColor(Color.argb(a, 0, 0, 0))
        }

        if (framed) canvas.restore()
    }

    private fun mix(home: Float, lock: Float, inv: Float): Float = home + (lock - home) * inv

    /** The cached filter for [gray] (0..1), rounded to the nearest 1/64. Allocates only the first time a step is used. */
    private fun grayFilterFor(gray: Float): ColorMatrixColorFilter {
        var step = (gray * GRAY_STEPS).roundToInt()
        if (step < 0) step = 0
        if (step > GRAY_STEPS) step = GRAY_STEPS
        var filter = grayFilters[step]
        if (filter == null) {
            colorMatrix.setSaturation(1f - step.toFloat() / GRAY_STEPS)
            filter = ColorMatrixColorFilter(colorMatrix)
            grayFilters[step] = filter
        }
        return filter
    }

    /** Draws [layer] (the sharp bitmap or a small blurred copy) so that it lands exactly where [sharp] would. */
    private fun drawLayer(canvas: Canvas, layer: Bitmap, sharp: Bitmap, k: Float, angle: Float, tx: Float, ty: Float) {
        if (layer === sharp) {
            matrix.setScale(k, k)
        } else {
            matrix.setScale(k * sharp.width / layer.width, k * sharp.height / layer.height)
        }
        if (angle != 0f) matrix.postRotate(angle, sharp.width * k / 2f, sharp.height * k / 2f)
        matrix.postTranslate(tx, ty)
        canvas.drawBitmap(layer, matrix, paint)
    }

    /**
     * Drops every decoded bitmap. The next configure() decodes again. Deliberately no Bitmap.recycle():
     * the GPU render thread may still reference the last frame; the native memory is freed as soon as
     * the last reference goes away.
     */
    fun release() {
        bitmap = null
        loadedKey = null
        sourceBitmapWidth = 0
        sourceBitmapHeight = 0
        bleedXpx = 0
        bleedYpx = 0
        clearSecondBitmap()
        blur1 = null
        blur2 = null
        blurKey = null
    }

    private fun buildBlur(sharp: Bitmap, screenWidth: Int, maxPct: Float) {
        val fullPx = maxPct / 100f * BLUR_MAX_PX * (screenWidth / 1080f)
        try {
            blur1 = BlurUtil.blur(sharp, max(2f, fullPx * 0.5f))
            blur2 = BlurUtil.blur(sharp, max(3f, fullPx))
        } catch (e: Exception) {
            Dbg.d { "blur build failed: $e" }
            blur1 = null
            blur2 = null
        } catch (e: OutOfMemoryError) {
            Dbg.d { "blur build OOM" }
            blur1 = null
            blur2 = null
        }
        Dbg.d { "blur levels built for ${maxPct.toInt()}% (${blur2?.width}x${blur2?.height})" }
    }

    /** Resize/crop the second photo once so it shares the primary photo's transform geometry. */
    /** Extend edge pixels by a few pixels; the photo itself is not scaled or cropped. */
    private fun addEdgeBleed(source: Bitmap, marginX: Int, marginY: Int): Bitmap {
        if (marginX <= 0 && marginY <= 0) return source
        val mx = max(0, marginX)
        val my = max(0, marginY)
        val out = Bitmap.createBitmap(source.width + mx * 2, source.height + my * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        val sw = source.width
        val sh = source.height
        c.drawBitmap(source, mx.toFloat(), my.toFloat(), p)
        if (mx > 0) {
            c.drawBitmap(source, Rect(0, 0, 1, sh), Rect(0, my, mx, my + sh), p)
            c.drawBitmap(source, Rect(sw - 1, 0, sw, sh), Rect(mx + sw, my, out.width, my + sh), p)
        }
        if (my > 0) {
            c.drawBitmap(source, Rect(0, 0, sw, 1), Rect(mx, 0, mx + sw, my), p)
            c.drawBitmap(source, Rect(0, sh - 1, sw, sh), Rect(mx, my + sh, mx + sw, out.height), p)
        }
        if (mx > 0 && my > 0) {
            c.drawBitmap(source, Rect(0, 0, 1, 1), Rect(0, 0, mx, my), p)
            c.drawBitmap(source, Rect(sw - 1, 0, sw, 1), Rect(mx + sw, 0, out.width, my), p)
            c.drawBitmap(source, Rect(0, sh - 1, 1, sh), Rect(0, my + sh, mx, out.height), p)
            c.drawBitmap(source, Rect(sw - 1, sh - 1, sw, sh), Rect(mx + sw, my + sh, out.width, out.height), p)
        }
        if (!source.isRecycled) source.recycle()
        return out
    }

    private fun clearSecondBitmap() {
        // Drop references rather than recycle: the render thread may still be finishing the last frame.
        secondBitmap = null
        secondLoadedKey = null
        secondBlur1 = null
        secondBlur2 = null
        secondBlurKey = null
    }

    private fun centerCrop(source: Bitmap, targetW: Int, targetH: Int): Bitmap {
        if (source.width == targetW && source.height == targetH) return source
        val scale = max(targetW.toFloat() / source.width, targetH.toFloat() / source.height)
        val scaledW = max(targetW, ceil(source.width * scale).toInt())
        val scaledH = max(targetH, ceil(source.height * scale).toInt())
        val scaled = Bitmap.createScaledBitmap(source, scaledW, scaledH, true)
        val x = (scaledW - targetW) / 2
        val y = (scaledH - targetH) / 2
        val cropped = Bitmap.createBitmap(scaled, x, y, targetW, targetH)
        if (scaled !== cropped && scaled !== source) scaled.recycle()
        if (source !== cropped && !source.isRecycled) source.recycle()
        return cropped
    }

    private fun decode(id: String, areaW: Int, areaH: Int): Bitmap? {
        val source = Wallpapers.openSource(context, id) ?: return null
        return try {
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val iw = info.size.width
                val ih = info.size.height
                val s = max(areaW.toFloat() / iw, areaH.toFloat() / ih)
                if (s < 1f) {
                    // Never keep more pixels than the screen can show. Never upscale here.
                    decoder.setTargetSize(
                        max(1, ceil(iw * s).toInt()),
                        max(1, ceil(ih * s).toInt())
                    )
                }
                // Software allocator: drawable on both hardware and software canvases.
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            }
        } catch (e: Exception) {
            Dbg.d { "decode failed for $id: $e" }
            null
        } catch (e: OutOfMemoryError) {
            Dbg.d { "decode OOM for $id" }
            null
        }
    }

    private companion object {
        /** Blur radius at 100% strength, in pixels of a 1080-wide screen. */
        const val BLUR_MAX_PX = 40f
        const val GRAY_STEPS = 64
        val FRAME_COLOR: Int = 0xFF0B0D10.toInt()
    }
}
