from pathlib import Path
root = Path(__file__).resolve().parents[1]
settings = (root / 'app/src/main/java/com/subtleunlock/wallpaper/Settings.kt').read_text()
service = (root / 'app/src/main/java/com/subtleunlock/wallpaper/UnlockWallpaperService.kt').read_text()
renderer = (root / 'app/src/main/java/com/subtleunlock/wallpaper/WallpaperRenderer.kt').read_text()
activity = (root / 'app/src/main/java/com/subtleunlock/wallpaper/SettingsActivity.kt').read_text()
workflow = (root / '.github/workflows/android.yml').read_text()
readme = (root / 'README.md').read_text()
checks = {
    'independent drawer look persisted': 'val drawer: Look' in settings and 'D_ZOOM' in settings and 'D_FADE' in settings,
    'desktop parallax has independent setting': 'desktopParallaxEnabled' in settings and 'desktopParallaxStrengthDp' in settings,
    'launcher zoom callback retained': 'override fun onZoomChanged' in service,
    'horizontal offsets handled independently': 'override fun onOffsetsChanged' in service and 'setOffsetNotificationsEnabled(true)' in service,
    'renderer consumes horizontal offset': 'desktopOffset: Float' in renderer and 'pageShift' in renderer,
    'second-image fade persisted and rendered': 'secondWallpaperId' in settings and 'fadePercent' in settings and 'secondBitmap' in renderer,
    'offline mode persisted and respected': 'offlineMode' in settings and 'settings.offlineMode' in service,
    'three independent UI tabs': all(x in activity for x in ['"Lock screen"', '"Home screen"', '"App drawer"']),
    'per-effect three-dot controls': 'pill("⋮", TONAL)' in activity and 'Customize $title' in activity,
    'wallpaper-derived app appearance': 'BlurUtil.blur(source' in activity and 'appBackgroundMode' in settings,
    'no sensor dependency introduced': 'SensorManager' not in service and 'TYPE_GYROSCOPE' not in service and 'TYPE_ACCELEROMETER' not in service,
    'CI installs Gradle 8.2 without wrapper': "gradle-version: '8.2'" in workflow and 'run: gradle assembleDebug' in workflow,
    'depth model status is stated honestly': 'not bundled or integrated' in readme.lower(),
}
for name, passed in checks.items():
    print(('PASS' if passed else 'FAIL') + ': ' + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f'feature checks: PASS ({len(checks)} checks)')
