package com.subtleunlock.wallpaper

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Builds a blurred copy of a bitmap on the CPU, cheaply: the picture is first shrunk by a power of two
 * (so the blur kernel is only a few pixels wide), blurred with three box-blur passes (a close
 * approximation of a Gaussian), and returned SMALL. It is drawn scaled back up with bilinear filtering,
 * which adds to the smoothness. A blurred picture holds no fine detail, so nothing visible is lost and
 * the memory cost is a fraction of the sharp bitmap.
 *
 * This runs only when the image, the output size or the blur settings change, never per frame.
 */
object BlurUtil {

    /** @param radiusPx blur radius in pixels of the FULL-size picture */
    fun blur(src: Bitmap, radiusPx: Float): Bitmap {
        val factor = factorFor(radiusPx)
        var cur = src
        var steps = factor
        while (steps > 1) {
            val w = max(1, cur.width / 2)
            val h = max(1, cur.height / 2)
            val previous = cur
            cur = Bitmap.createScaledBitmap(previous, w, h, true)
            if (previous !== src && !previous.isRecycled) previous.recycle()
            steps /= 2
        }
        val w = cur.width
        val h = cur.height
        val px = IntArray(w * h)
        cur.getPixels(px, 0, w, 0, 0, w, h)
        if (cur !== src && !cur.isRecycled) cur.recycle()
        val rho = max(1, (radiusPx / factor / 2f).roundToInt())
        boxBlur(px, w, h, rho)
        boxBlur(px, w, h, rho)
        boxBlur(px, w, h, rho)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Power-of-two shrink factor (2..16) that leaves a kernel of roughly 3 px. */
    fun factorFor(radiusPx: Float): Int {
        val target = radiusPx / 3f
        var f = 2
        while (f < 16 && f * 1.4142f <= target) f *= 2
        return f
    }

    /** One box blur (horizontal then vertical), edge pixels replicated. Pixels are treated as opaque. */
    fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val win = 2 * r + 1
        val tmp = IntArray(w * h)

        // horizontal
        for (y in 0 until h) {
            val row = y * w
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = px[row + clamp(i, w - 1)]
                sr += (c shr 16) and 0xFF
                sg += (c shr 8) and 0xFF
                sb += c and 0xFF
            }
            for (x in 0 until w) {
                tmp[row + x] = (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
                val add = px[row + clamp(x + r + 1, w - 1)]
                val sub = px[row + clamp(x - r, w - 1)]
                sr += ((add shr 16) and 0xFF) - ((sub shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((sub shr 8) and 0xFF)
                sb += (add and 0xFF) - (sub and 0xFF)
            }
        }

        // vertical
        for (x in 0 until w) {
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = tmp[clamp(i, h - 1) * w + x]
                sr += (c shr 16) and 0xFF
                sg += (c shr 8) and 0xFF
                sb += c and 0xFF
            }
            for (y in 0 until h) {
                px[y * w + x] = (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
                val add = tmp[clamp(y + r + 1, h - 1) * w + x]
                val sub = tmp[clamp(y - r, h - 1) * w + x]
                sr += ((add shr 16) and 0xFF) - ((sub shr 16) and 0xFF)
                sg += ((add shr 8) and 0xFF) - ((sub shr 8) and 0xFF)
                sb += (add and 0xFF) - (sub and 0xFF)
            }
        }
    }

    private fun clamp(i: Int, maxIndex: Int): Int = if (i < 0) 0 else if (i > maxIndex) maxIndex else i
}
