package com.subtleunlock.wallpaper

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * In-memory ring buffer of recent events (unlock signals, visibility, transitions), so behaviour can
 * be inspected on the phone itself without a PC. Fed by Dbg, i.e. debug builds only; in release
 * builds nothing is recorded. Never written to disk, never transmitted.
 */
object EventLog {
    private const val MAX_LINES = 120
    private val lines = java.util.ArrayDeque<String>()
    private val format = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun add(message: String) {
        lines.addLast(format.format(Date()) + "  " + message)
        while (lines.size > MAX_LINES) lines.removeFirst()
    }

    @Synchronized
    fun dump(): String {
        if (lines.isEmpty()) return "(no events recorded yet)"
        val sb = StringBuilder()
        for (line in lines) sb.append(line).append('\n')
        return sb.toString()
    }

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
