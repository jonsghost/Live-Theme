package com.subtleunlock.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Draws one wallpaper picture blended between its LOCK look and its HOME look, plus horizontal home-screen desktop parallax.
 *
 * Design (unchanged from v1.3 where it matters):
 *  - The picture is decoded ONCE at exactly the size needed to cover the screen plus every margin the
 *    current settings can need (slide reach, tilt, zoom-out headroom). Nothing is decoded while animating.
 *  - Margins come from the settings, so no edge can ever become visible.
 *  - With every new effect at zero, draw() takes the same single-bitmap path as v1.3, and the plain
 *    HOME look is drawn at base scale with an integer position (the original pixels).
 *  - draw() reuses one Matrix, one Paint, one Path: no allocations per frame.
 *
 * New in v1.4 (all cached, none computed per frame):
 *  - Grayscale: a colour-matrix filter on the Paint (GPU), updated in place.
 *  - Blur: two small pre-blurred copies (half and full strength) built when the picture, size or blur
 *    settings change; a frame cross-fades between sharp -> half -> full. A few hundred KB, not a
 *    second full-size bitmap.
 *  - Frame: the picture is clipped to an inset rounded rectangle over a dark background.
 *  - Fade: darkening, as before.
 *
 * progress: 0 = LOCK look ... 1 = HOME look (springy easing may pass slightly beyond either end).
 * parallax: -1..1, horizontal desktop-page position relative to the centre page. Only used at HOME.
 */
class WallpaperRenderer(private val context: Context) {

    private var bitmap: Bitmap? = null
    private var loadedKey: String? = null

    private var blur1: Bitmap? = null
    private var blur2: Bitmap? = null
    private var blurKey: String? = null

    private var screenW = 0
    private var screenH = 0
    private var baseScale = 1f
    private var restTx = 0f
    private var restTy = 0f
    private var ux = 0f
    private var uy = 0f
    private var lockSlidePx = 0f
    private var homeSlidePx = 0f
    private var parallaxTravelPx = 0f
    private var lockZoom = 0f
    private var homeZoom = 0f
    private var lockTilt = 0f
    private var homeTilt = 0f
    private var lockDim = 0f
    private var homeDim = 0f
    private var lockGray = 0f
    private var homeGray = 0f
    private var lockBlur = 0f
    private var homeBlur = 0f
    private var blurMaxPct = 0f
    private var lockInset = 0f
    private var homeInset = 0f
    private var insetRef = 1f
    private var cornerPx = 0f
    private var kFloor = 1f

    private val matrix = Matrix()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val colorMatrix = ColorMatrix()
    private val grayFilter = ColorMatrixColorFilter(colorMatrix)
    private val framePath = Path()
    private val frameRect = RectF()

    val isReady: Boolean get() = bitmap != null

    /**
     * Prepares geometry (and decodes / blurs if needed) for a surface of [w] x [h] pixels.
     * Cheap when nothing relevant changed. May decode on the calling thread (never call while animating).
     * @param pxPerDp pixels per dp for this surface (the preview passes a scaled value)
     * @return true if something can be drawn
     */
    fun configure(w: Int, h: Int, s: MotionSettings, pxPerDp: Float): Boolean {
        if (w <= 0 || h <= 0) return false
        val lock = s.lock
        val home = s.home

        // Springy easing overshoots by ~13%; plan margins for 15%.
        val ovf = if (s.easing == Easing.SPRING) 1.15f else 1f
        // The value at any moment is home + (lock - home) * inv with inv in [1 - ovf, ovf].
        fun bound(a: Float, b: Float): Float {
            val big = max(a, b)
            val small = min(a, b)
            return if (ovf > 1f) big * ovf + small * (ovf - 1f) else big
        }

        val lockSlide = lock.slideDp * pxPerDp
        val homeSlide = home.slideDp * pxPerDp
        val dParallax = if (s.desktopParallaxEnabled) s.desktopParallaxStrengthDp * pxPerDp else 0f
        val reach = bound(lockSlide, homeSlide)
        val reachX = reach * abs(s.direction.ux)
        val reachY = reach * abs(s.direction.uy)

        // Tilt: the picture must still cover the screen when rotated about its centre, and the slide
        // reach must be measured along the TILTED axes (a vertical slide also eats into the tilted width).
        val maxTiltDeg = bound(lock.tiltTenths / 10f, home.tiltTenths / 10f)
        val rad = Math.toRadians(maxTiltDeg.toDouble())
        val cosA = cos(rad)
        val sinA = sin(rad)
        val rotW = w * cosA + h * sinA + 2.0 * (reachX * cosA + reachY * sinA)
        val rotH = w * sinA + h * cosA + 2.0 * (reachX * sinA + reachY * cosA)

        // Zoom-out headroom: the base picture is this much larger than needed, so scaling it down by
        // up to the same factor still covers everything.
        val zl = lock.zoomPercent / 100f
        val zh = home.zoomPercent / 100f
        var kMinRel = min(1f, min(1f + zl, 1f + zh))
        kMinRel = min(kMinRel, 1f + (zh + (zl - zh) * ovf))
        val headroom = 1f / kMinRel

        // +2 px: spare pixels so the half-pixel rounding of the rest position can never expose an edge.
        val baseAreaW = ceil((rotW + 2.0) * headroom).toInt()
        val baseAreaH = ceil((rotH + 2.0) * headroom).toInt()
        // Extra overscan keeps the full image inside the viewport at both ends of a desktop swipe.
        val parallaxMargin = ceil(3.0 * dParallax * ovf).toInt()
        // Reserve margin on both bitmap axes so it remains sufficient after any configured tilt.
        val areaW = baseAreaW + parallaxMargin
        val areaH = baseAreaH + parallaxMargin

        val key = s.wallpaperId + "|" + areaW + "x" + areaH
        if (bitmap == null || key != loadedKey) {
            var decoded = decode(s.wallpaperId, areaW, areaH)
            if (decoded == null && s.wallpaperId != Wallpapers.DEFAULT_ID) {
                // Missing/corrupt custom image: fall back to the bundled default instead of a black screen.
                decoded = decode(Wallpapers.DEFAULT_ID, areaW, areaH)
            }
            if (decoded == null) return false
            bitmap = decoded
            loadedKey = key // also set after a fallback, so a failing decode is not retried on every call
        }

        val bmp = bitmap ?: return false
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        baseScale = max(areaW / bw, areaH / bh)
        // Integer rest position: crisp pixels, no half-pixel blur in the plain HOME look.
        restTx = ((w - bw * baseScale) / 2f).roundToInt().toFloat()
        restTy = ((h - bh * baseScale) / 2f).roundToInt().toFloat()

        screenW = w
        screenH = h
        ux = s.direction.ux
        uy = s.direction.uy
        lockSlidePx = lockSlide
        homeSlidePx = homeSlide
        parallaxTravelPx = dParallax
        lockZoom = zl
        homeZoom = zh
        lockTilt = lock.tiltTenths / 10f
        homeTilt = home.tiltTenths / 10f
        lockDim = lock.dimPercent / 100f
        homeDim = home.dimPercent / 100f
        lockGray = lock.grayPercent / 100f
        homeGray = home.grayPercent / 100f
        lockBlur = lock.blurPercent.toFloat()
        homeBlur = home.blurPercent.toFloat()
        lockInset = lock.insetDp * pxPerDp
        homeInset = home.insetDp * pxPerDp
        insetRef = max(1f, max(lockInset, homeInset))
        cornerPx = s.frameCornerDp * pxPerDp
        kFloor = 1f / headroom

        // Blur levels: rebuilt only when the picture, the screen width or the strongest blur changes.
        blurMaxPct = max(lockBlur, homeBlur)
        if (blurMaxPct > 0f) {
            val bk = key + "|" + blurMaxPct.toInt() + "|" + w
            if (blur2 == null || bk != blurKey) {
                buildBlur(bmp, w, blurMaxPct)
                blurKey = bk
            }
        } else {
            blur1 = null
            blur2 = null
            blurKey = null
        }
        return true
    }

    /** Draws one frame. No allocations. See the class comment for [progress] and [parallax]. */
    fun draw(canvas: Canvas, progress: Float, parallax: Float) {
        val bmp = bitmap
        if (bmp == null) {
            canvas.drawColor(Color.BLACK)
            return
        }
        val inv = 1f - progress // 1 = LOCK look, 0 = HOME look

        var k = baseScale * (1f + mix(homeZoom, lockZoom, inv))
        val kMin = baseScale * kFloor
        if (k < kMin) k = kMin // can only trigger on overshoot; headroom already covers the settings

        val slide = mix(homeSlidePx, lockSlidePx, inv)
        val parallaxOffset = if (progress >= 0.999f) parallaxTravelPx * parallax.coerceIn(-1f, 1f) else 0f
        val tx = restTx + (bmp.width * baseScale - bmp.width * k) / 2f + ux * slide - parallaxOffset
        val ty = restTy + (bmp.height * baseScale - bmp.height * k) / 2f + uy * slide
        val angle = mix(homeTilt, lockTilt, inv)

        var dim = mix(homeDim, lockDim, inv)
        if (dim < 0f) dim = 0f
        var gray = mix(homeGray, lockGray, inv)
        gray = if (gray < 0f) 0f else if (gray > 1f) 1f else gray
        var inset = mix(homeInset, lockInset, inv)
        if (inset < 0f) inset = 0f

        val l1 = blur1
        val l2 = blur2
        var pos = 0f // 0 = sharp, 1 = half blur, 2 = full blur
        if (blurMaxPct > 0f && l1 != null && l2 != null) {
            val b = mix(homeBlur, lockBlur, inv) / blurMaxPct
            pos = (if (b < 0f) 0f else if (b > 1f) 1f else b) * 2f
        }

        val framed = inset > 0.5f
        if (framed) {
            canvas.drawColor(FRAME_COLOR)
            canvas.save()
            framePath.reset()
            frameRect.set(inset, inset, screenW - inset, screenH - inset)
            val corner = cornerPx * min(1f, inset / insetRef)
            framePath.addRoundRect(frameRect, corner, corner, Path.Direction.CW)
            canvas.clipPath(framePath)
        }

        if (gray > 0.002f) {
            colorMatrix.setSaturation(1f - gray)
            grayFilter.setColorMatrix(colorMatrix)
            paint.colorFilter = grayFilter
        } else {
            paint.colorFilter = null
        }

        if (pos <= 0.001f || l1 == null || l2 == null) {
            // Single-bitmap path: identical to v1.3 when no new effect is active.
            var alpha = 255 - (dim * 255f).toInt()
            if (alpha < 0) alpha = 0
            paint.alpha = alpha
            if (alpha < 255) canvas.drawColor(Color.BLACK)
            drawLayer(canvas, bmp, bmp, k, angle, tx, ty)
        } else {
            paint.alpha = 255
            val idx = if (pos >= 2f) 2 else pos.toInt()
            val frac = pos - idx
            val first = if (idx == 0) bmp else if (idx == 1) l1 else l2
            drawLayer(canvas, first, bmp, k, angle, tx, ty)
            if (idx < 2 && frac > 0.004f) {
                paint.alpha = (frac * 255f).toInt()
                drawLayer(canvas, if (idx == 0) l1 else l2, bmp, k, angle, tx, ty)
                paint.alpha = 255
            }
            if (dim > 0f) {
                val a = (dim * 255f).toInt()
                canvas.drawColor(Color.argb(if (a > 255) 255 else a, 0, 0, 0))
            }
        }

        if (framed) canvas.restore()
    }

    private fun mix(home: Float, lock: Float, inv: Float): Float = home + (lock - home) * inv

    /** Draws [layer] (the sharp bitmap or a small blurred copy) so that it lands exactly where [sharp] would. */
    private fun drawLayer(canvas: Canvas, layer: Bitmap, sharp: Bitmap, k: Float, angle: Float, tx: Float, ty: Float) {
        if (layer === sharp) {
            matrix.setScale(k, k)
        } else {
            matrix.setScale(k * sharp.width / layer.width, k * sharp.height / layer.height)
        }
        if (angle != 0f) matrix.postRotate(angle, sharp.width * k / 2f, sharp.height * k / 2f)
        matrix.postTranslate(tx, ty)
        canvas.drawBitmap(layer, matrix, paint)
    }

    /**
     * Drops every decoded bitmap. The next configure() decodes again. Deliberately no Bitmap.recycle():
     * the GPU render thread may still reference the last frame; the native memory is freed as soon as
     * the last reference goes away.
     */
    fun release() {
        bitmap = null
        loadedKey = null
        blur1 = null
        blur2 = null
        blurKey = null
    }

    private fun buildBlur(sharp: Bitmap, screenWidth: Int, maxPct: Float) {
        val fullPx = maxPct / 100f * BLUR_MAX_PX * (screenWidth / 1080f)
        try {
            blur1 = BlurUtil.blur(sharp, max(2f, fullPx * 0.5f))
            blur2 = BlurUtil.blur(sharp, max(3f, fullPx))
        } catch (e: Exception) {
            Dbg.d { "blur build failed: $e" }
            blur1 = null
            blur2 = null
        } catch (e: OutOfMemoryError) {
            Dbg.d { "blur build OOM" }
            blur1 = null
            blur2 = null
        }
        Dbg.d { "blur levels built for ${maxPct.toInt()}% (${blur2?.width}x${blur2?.height})" }
    }

    private fun decode(id: String, areaW: Int, areaH: Int): Bitmap? {
        val source = Wallpapers.openSource(context, id) ?: return null
        return try {
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val iw = info.size.width
                val ih = info.size.height
                val s = max(areaW.toFloat() / iw, areaH.toFloat() / ih)
                if (s < 1f) {
                    // Never keep more pixels than the screen can show. Never upscale here.
                    decoder.setTargetSize(
                        max(1, ceil(iw * s).toInt()),
                        max(1, ceil(ih * s).toInt())
                    )
                }
                // Software allocator: drawable on both hardware and software canvases.
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            }
        } catch (e: Exception) {
            Dbg.d { "decode failed for $id: $e" }
            null
        } catch (e: OutOfMemoryError) {
            Dbg.d { "decode OOM for $id" }
            null
        }
    }

    private companion object {
        /** Blur radius at 100% strength, in pixels of a 1080-wide screen. */
        const val BLUR_MAX_PX = 40f
        val FRAME_COLOR: Int = 0xFF0B0D10.toInt()
    }
}
