package com.subtleunlock.wallpaper

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.transition.TransitionManager
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Material 3 style settings screen, built from plain platform widgets (no AppCompat / Material
 * dependency): dynamic colour on Android 12+, light and dark themes, rounded cards, pill buttons,
 * ripple + press feedback on everything tappable.
 */
class SettingsActivity : Activity() {

    private class Palette(
        val bg: Int,
        val container: Int,
        val tile: Int,
        val onSurface: Int,
        val onSurfaceVariant: Int,
        val primary: Int,
        val onPrimary: Int,
        val primaryContainer: Int,
        val onPrimaryContainer: Int,
        val outline: Int,
        val track: Int,
        val night: Boolean
    )

    private class StyleTile(val id: String, val view: View, val title: TextView, val desc: TextView)

    private lateinit var pal: Palette
    private lateinit var s: MotionSettings
    private lateinit var scroll: ScrollView
    private lateinit var rootLayout: LinearLayout
    private lateinit var preview: PreviewView
    private lateinit var statusText: TextView
    private lateinit var styleStatus: TextView
    private lateinit var thumbRow: LinearLayout
    private lateinit var enableSwitch: Switch
    private lateinit var holdSwitch: Switch
    private lateinit var lockAnimSwitch: Switch
    private lateinit var reducedSwitch: Switch
    private lateinit var parallaxSwitch: Switch
    private lateinit var fallbackSwitch: Switch

    private val styleTiles = ArrayList<StyleTile>()

    /** Each entry re-reads [s] into one slider / spinner. */
    private val syncers = ArrayList<() -> Unit>()
    private var syncing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = SettingsStore.load(this)
        pal = buildPalette()
        applyWindow()
        setContentView(buildUi())
        syncControls()
        rebuildThumbs()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------------ colours

    private fun buildPalette(): Palette {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                return dynamicPalette(night)
            } catch (e: Exception) {
                // fall through to the fixed palette
            }
        }
        return if (night) {
            Palette(
                bg = 0xFF111318.toInt(), container = 0xFF1D2024.toInt(), tile = 0xFF282B31.toInt(),
                onSurface = 0xFFE2E2E9.toInt(), onSurfaceVariant = 0xFFC4C6D0.toInt(),
                primary = 0xFFAAC7FF.toInt(), onPrimary = 0xFF0A305F.toInt(),
                primaryContainer = 0xFF284777.toInt(), onPrimaryContainer = 0xFFD8E2FF.toInt(),
                outline = 0xFF8E9099.toInt(), track = 0xFF43474E.toInt(), night = true
            )
        } else {
            Palette(
                bg = 0xFFF8F9FC.toInt(), container = 0xFFEDF0F7.toInt(), tile = 0xFFE1E5EE.toInt(),
                onSurface = 0xFF1A1C20.toInt(), onSurfaceVariant = 0xFF44474F.toInt(),
                primary = 0xFF2F5FA7.toInt(), onPrimary = 0xFFFFFFFF.toInt(),
                primaryContainer = 0xFFD8E2FF.toInt(), onPrimaryContainer = 0xFF001A41.toInt(),
                outline = 0xFF74777F.toInt(), track = 0xFFDDE3EA.toInt(), night = false
            )
        }
    }

    /** Android 12 "Material You" palette from the system tonal resources. */
    private fun dynamicPalette(night: Boolean): Palette {
        fun c(id: Int): Int = getColor(id)
        return if (night) {
            val container = c(android.R.color.system_neutral1_800)
            Palette(
                bg = c(android.R.color.system_neutral1_900),
                container = container,
                tile = blend(container, c(android.R.color.system_neutral1_0), 0.08f),
                onSurface = c(android.R.color.system_neutral1_100),
                onSurfaceVariant = c(android.R.color.system_neutral2_200),
                primary = c(android.R.color.system_accent1_200),
                onPrimary = c(android.R.color.system_accent1_800),
                primaryContainer = c(android.R.color.system_accent1_700),
                onPrimaryContainer = c(android.R.color.system_accent1_100),
                outline = c(android.R.color.system_neutral2_400),
                track = c(android.R.color.system_neutral2_700),
                night = true
            )
        } else {
            val container = c(android.R.color.system_neutral2_50)
            Palette(
                bg = c(android.R.color.system_neutral1_10),
                container = container,
                tile = blend(container, c(android.R.color.system_neutral1_900), 0.05f),
                onSurface = c(android.R.color.system_neutral1_900),
                onSurfaceVariant = c(android.R.color.system_neutral2_700),
                primary = c(android.R.color.system_accent1_600),
                onPrimary = c(android.R.color.system_accent1_0),
                primaryContainer = c(android.R.color.system_accent1_100),
                onPrimaryContainer = c(android.R.color.system_accent1_900),
                outline = c(android.R.color.system_neutral2_500),
                track = c(android.R.color.system_neutral2_100),
                night = false
            )
        }
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1f - t) + Color.red(b) * t).roundToInt()
        val g = (Color.green(a) * (1f - t) + Color.green(b) * t).roundToInt()
        val bl = (Color.blue(a) * (1f - t) + Color.blue(b) * t).roundToInt()
        return Color.rgb(r, g, bl)
    }

    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    @Suppress("DEPRECATION")
    private fun applyWindow() {
        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        if (!pal.night) {
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    // ------------------------------------------------------------------ UI construction

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(36))
        rootLayout = root

        root.addView(text("Subtle Unlock Motion", 28f, pal.onSurface, bold = true), lp(top = 4))
        root.addView(
            text("Subtle wallpaper motion for locking, unlocking and horizontal home-screen page swipes.", 14f, pal.onSurfaceVariant),
            lp(top = 4)
        )
        statusText = text("", 13f, pal.onPrimaryContainer, bold = true)
        statusText.setPadding(dp(14), dp(7), dp(14), dp(7))
        statusText.background = ripple(pal.primaryContainer, dp(20).toFloat())
        root.addView(statusText, wrapLp(top = 14))

        // ---- Wallpaper + preview
        val previewCard = card()
        preview = PreviewView(this)
        val dm = resources.displayMetrics
        val shortSide = min(dm.widthPixels, dm.heightPixels)
        val longSide = max(dm.widthPixels, dm.heightPixels)
        val pw = (shortSide * 0.46f).roundToInt()
        val ph = (pw * (longSide.toFloat() / shortSide)).roundToInt()
        previewCard.addView(preview, LinearLayout.LayoutParams(pw, ph).apply { gravity = Gravity.CENTER_HORIZONTAL })

        val lookRow = row()
        lookRow.addView(pill("Lock look", TONAL) { preview.showPose(0f) }, weighted())
        lookRow.addView(pill("Home look", TONAL) { preview.showPose(1f) }, weighted())
        previewCard.addView(lookRow, lp(top = 14))
        val playRow = row()
        playRow.addView(pill("Unlock", FILLED) { demo { preview.playUnlock() } }, weighted())
        playRow.addView(pill("Lock", TONAL) { demo { preview.playLock() } }, weighted())
        previewCard.addView(playRow, lp(top = 8))

        thumbRow = LinearLayout(this)
        thumbRow.orientation = LinearLayout.HORIZONTAL
        previewCard.addView(thumbRow, lp(top = 16))
        previewCard.addView(pill("Choose your own picture", OUTLINED) { pickImage() }, lp(top = 12))
        root.addView(previewCard, lp(top = 16))

        root.addView(pill("Set as live wallpaper", FILLED) { confirmSetWallpaper() }, lp(top = 14))

        // ---- Animation styles
        val styleCard = card()
        styleCard.addView(text("Animation style", 18f, pal.onSurface, bold = true))
        styleStatus = text("", 13f, pal.primary, bold = true)
        styleCard.addView(styleStatus, lp(top = 6))
        styleCard.addView(
            text("Pick a starting point, then fine-tune below. Any change turns it into Custom.", 12f, pal.onSurfaceVariant),
            lp(top = 4)
        )
        val tiles = ArrayList<View>()
        for (p in Presets.main) tiles.add(styleTile(p, p.id, p.name, p.description))
        tiles.add(styleTile(null, "custom", "Custom", "Keep your current settings and combine effects yourself."))
        var i = 0
        while (i < tiles.size) {
            val r = row()
            r.addView(tiles[i], tileLp())
            if (i + 1 < tiles.size) r.addView(tiles[i + 1], tileLp()) else r.addView(View(this), tileLp())
            styleCard.addView(r, lp(top = 8))
            i += 2
        }
        root.addView(styleCard, lp(top = 16))

        // ---- Lock screen look
        val lockCard = card()
        lockCard.addView(text("Lock screen look", 18f, pal.onSurface, bold = true))
        lockCard.addView(text("How the wallpaper looks while the phone is locked.", 12f, pal.onSurfaceVariant), lp(top = 2))
        addLookBasics(lockCard, true)
        root.addView(lockCard, lp(top = 16))

        // ---- Home screen look
        val homeCard = card()
        homeCard.addView(text("Home screen look", 18f, pal.onSurface, bold = true))
        homeCard.addView(text("How it looks after unlocking. Plain is the original picture.", 12f, pal.onSurfaceVariant), lp(top = 2))
        addLookBasics(homeCard, false)
        root.addView(homeCard, lp(top = 16))

        // ---- Transition
        val transCard = card()
        transCard.addView(text("Transition", 18f, pal.onSurface, bold = true))
        transCard.addView(text("How the wallpaper moves from one look to the other when you unlock or lock.", 12f, pal.onSurfaceVariant), lp(top = 2))
        addSlider(transCard, 150, 1200, 50, { v -> "Duration: $v ms" }, { s.durationMs }) { st, v -> st.copy(durationMs = v) }
        addChoice(
            transCard, "Motion shape", Easing.values().map { it.label }, { s.easing.ordinal }
        ) { idx -> update(s.copy(easing = Easing.values()[idx])) }
        enableSwitch = styledSwitch("Enable motion") { c -> update(s.copy(enabled = c)) }
        transCard.addView(enableSwitch, lp(top = 14))
        holdSwitch = styledSwitch("Rest in the lock look while locked") { c -> update(s.copy(holdLockPose = c)) }
        transCard.addView(holdSwitch, lp(top = 4))
        transCard.addView(
            text("Unlocking then starts from what is already on screen, so there is no jump. Off = classic behaviour.", 12f, pal.onSurfaceVariant),
            lp(top = 0)
        )
        lockAnimSwitch = styledSwitch("Animate into the lock look when the screen wakes") { c -> update(s.copy(lockAnimate = c)) }
        transCard.addView(lockAnimSwitch, lp(top = 4))
        reducedSwitch = styledSwitch("Reduced motion (effects switch instantly)") { c -> update(s.copy(reducedMotion = c)) }
        transCard.addView(reducedSwitch, lp(top = 4))
        transCard.addView(
            text("Android's own \"Remove animations\" setting is always respected as well.", 12f, pal.onSurfaceVariant),
            lp(top = 0)
        )
        root.addView(transCard, lp(top = 16))

        // ---- Advanced
        val adv = LinearLayout(this)
        adv.orientation = LinearLayout.VERTICAL
        adv.addView(text("Lock look: slide and tilt", 14f, pal.onSurface, bold = true), lp(top = 4))
        addLookAdvanced(adv, true)
        adv.addView(text("Home look: slide and tilt", 14f, pal.onSurface, bold = true), lp(top = 20))
        addLookAdvanced(adv, false)
        adv.addView(text("Slide and frame", 14f, pal.onSurface, bold = true), lp(top = 20))
        addChoice(
            adv, "Slide direction", Direction.values().map { it.label }, { s.direction.ordinal }
        ) { idx -> update(s.copy(direction = Direction.values()[idx])) }
        addSlider(adv, 0, 40, 1, { v -> "Frame corner radius: $v dp" }, { s.frameCornerDp }) { st, v -> st.copy(frameCornerDp = v) }

        adv.addView(text("Home-screen desktop parallax", 14f, pal.onSurface, bold = true), lp(top = 20))
        parallaxSwitch = styledSwitch("Enable horizontal desktop parallax") { c -> update(s.copy(desktopParallaxEnabled = c)) }
        adv.addView(parallaxSwitch, lp(top = 4))
        adv.addView(
            text("Moves the wallpaper subtly as you swipe left or right between home-screen pages. It does not react to the app drawer or app opening. No gyroscope or accelerometer is used.", 12f, pal.onSurfaceVariant),
            lp(top = 0)
        )
        addSlider(adv, 0, 36, 1, { v -> "Parallax travel: $v dp" }, { s.desktopParallaxStrengthDp }) { st, v -> st.copy(desktopParallaxStrengthDp = v) }

        adv.addView(text("Detection", 14f, pal.onSurface, bold = true), lp(top = 20))
        fallbackSwitch = styledSwitch("Also trigger on wallpaper visibility (experimental)") { c -> update(s.copy(visibilityFallback = c)) }
        adv.addView(fallbackSwitch, lp(top = 4))
        adv.addView(
            text("Only if the unlock broadcast does not fire on your device.", 12f, pal.onSurfaceVariant),
            lp(top = 0)
        )

        adv.addView(text("Earlier styles", 14f, pal.onSurface, bold = true), lp(top = 20))
        val old = ArrayList<View>()
        for (p in Presets.legacy) old.add(styleTile(p, p.id, p.name, p.description))
        var j = 0
        while (j < old.size) {
            val r = row()
            r.addView(old[j], tileLp())
            if (j + 1 < old.size) r.addView(old[j + 1], tileLp()) else r.addView(View(this), tileLp())
            adv.addView(r, lp(top = 8))
            j += 2
        }

        adv.addView(pill("Reset to Classic Frame Zoom", OUTLINED) { resetDefaults() }, lp(top = 20))
        adv.addView(pill("Diagnostics: recent unlock events", OUTLINED) { showEvents() }, lp(top = 8))
        adv.addView(pill("Battery and autostart (app info)", OUTLINED) { openAppInfo() }, lp(top = 8))

        val advCard = card()
        advCard.addView(expandable("Advanced settings", adv))
        root.addView(advCard, lp(top = 16))

        root.addView(
            text(
                "Android decides which screens (home, lock or both) the live wallpaper is applied to. " +
                    "Nothing is replaced until you confirm in the system screen. " +
                    "This app cannot change the system's own lock and unlock animation; it draws its own " +
                    "movement of the wallpaper when it detects the unlock.",
                12f, pal.onSurfaceVariant
            ), lp(top = 16)
        )

        scroll = ScrollView(this)
        scroll.setBackgroundColor(pal.bg)
        scroll.addView(root)
        return scroll
    }

    private fun zoomText(v: Int): String = when {
        v < 0 -> "Zoom: $v%  (zoomed out)"
        v > 0 -> "Zoom: +$v%  (zoomed in)"
        else -> "Zoom: off"
    }

    private fun look(st: MotionSettings, isLock: Boolean): Look = if (isLock) st.lock else st.home

    private fun withLook(st: MotionSettings, isLock: Boolean, l: Look): MotionSettings =
        if (isLock) st.copy(lock = l) else st.copy(home = l)

    private fun addLookBasics(parent: LinearLayout, isLock: Boolean) {
        addSlider(parent, -10, 10, 1, { v -> zoomText(v) }, { look(s, isLock).zoomPercent }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(zoomPercent = v))
        }
        addSlider(parent, 0, 24, 1, { v -> if (v == 0) "Frame: off" else "Frame inset: $v dp" }, { look(s, isLock).insetDp }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(insetDp = v))
        }
        addSlider(parent, 0, 100, 5, { v -> "Grayscale: $v%" }, { look(s, isLock).grayPercent }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(grayPercent = v))
        }
        addSlider(parent, 0, 100, 5, { v -> "Blur: $v%" }, { look(s, isLock).blurPercent }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(blurPercent = v))
        }
        addSlider(parent, 0, 60, 5, { v -> "Fade (darken): $v%" }, { look(s, isLock).dimPercent }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(dimPercent = v))
        }
    }

    private fun addLookAdvanced(parent: LinearLayout, isLock: Boolean) {
        addSlider(parent, 0, 48, 1, { v -> "Slide: $v dp" }, { look(s, isLock).slideDp }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(slideDp = v))
        }
        addSlider(parent, 0, 30, 1, { v -> "Tilt: " + (v / 10) + "." + (v % 10) + " degrees" }, { look(s, isLock).tiltTenths }) { st, v ->
            withLook(st, isLock, look(st, isLock).copy(tiltTenths = v))
        }
    }

    // ------------------------------------------------------------------ styles

    private fun styleTile(preset: Presets.Preset?, id: String, title: String, desc: String): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.setPadding(dp(14), dp(12), dp(14), dp(12))
        val t1 = text(title, 14f, pal.onSurface, bold = true)
        val t2 = text(desc, 12f, pal.onSurfaceVariant)
        tile.addView(t1)
        tile.addView(t2, lp(top = 4))
        tile.isClickable = true
        tile.isFocusable = true
        tile.setOnClickListener { applyStyle(preset) }
        pressable(tile)
        styleTiles.add(StyleTile(id, tile, t1, t2))
        return tile
    }

    private fun applyStyle(preset: Presets.Preset?) {
        val next = if (preset == null) s.copy(styleId = "custom") else preset.transform(s).copy(styleId = preset.id)
        update(next)
        syncControls()
        toast((preset?.name ?: "Custom") + " selected")
        scroll.post { scroll.smoothScrollTo(0, 0) }
        preview.postDelayed({ preview.playUnlock() }, 380L)
    }

    private fun currentStyleId(): String {
        val chosen = Presets.byId(s.styleId)
        if (chosen != null && chosen.transform(s) == s) return chosen.id
        return Presets.matching(s)?.id ?: "custom"
    }

    private fun refreshStyleUi() {
        styleStatus.text = "Current: " + Presets.label(s)
        val sel = currentStyleId()
        val r = dp(18).toFloat()
        for (t in styleTiles) {
            if (t.id == sel) {
                t.view.background = ripple(pal.primaryContainer, r)
                t.title.setTextColor(pal.onPrimaryContainer)
                t.desc.setTextColor(pal.onPrimaryContainer)
            } else {
                t.view.background = ripple(pal.tile, r)
                t.title.setTextColor(pal.onSurface)
                t.desc.setTextColor(pal.onSurfaceVariant)
            }
        }
    }

    // ------------------------------------------------------------------ state <-> controls

    private fun update(newSettings: MotionSettings) {
        if (syncing) return
        s = newSettings
        SettingsStore.save(this, newSettings)
        preview.applySettings(newSettings)
        refreshStyleUi()
    }

    private fun syncControls() {
        syncing = true
        enableSwitch.isChecked = s.enabled
        holdSwitch.isChecked = s.holdLockPose
        lockAnimSwitch.isChecked = s.lockAnimate
        reducedSwitch.isChecked = s.reducedMotion
        parallaxSwitch.isChecked = s.desktopParallaxEnabled
        fallbackSwitch.isChecked = s.visibilityFallback
        for (sync in syncers) sync()
        syncing = false
        refreshStyleUi()
    }

    private fun resetDefaults() {
        SettingsStore.resetMotionToDefaults(this)
        s = SettingsStore.load(this)
        preview.applySettings(s)
        syncControls()
        toast("Reset to Classic Frame Zoom")
    }

    private fun refreshStatus() {
        val info = WallpaperManager.getInstance(this).wallpaperInfo
        val active = info != null &&
            info.packageName == packageName &&
            info.serviceName == UnlockWallpaperService::class.java.name
        statusText.text = if (active) {
            "Live wallpaper is active on the home screen"
        } else {
            "Not applied yet. Tap \"Set as live wallpaper\"."
        }
    }

    private fun demo(play: () -> Unit) {
        if (s.reducedMotion || !ValueAnimator.areAnimatorsEnabled()) {
            toast("Reduced motion is on, so the real wallpaper switches instantly. Playing the preview anyway.")
        }
        play()
    }

    // ------------------------------------------------------------------ controls

    /** A labelled slider. [min]..[max] in steps of [step]; [write] returns the new settings for a value. */
    private fun addSlider(
        parent: LinearLayout,
        min: Int,
        max: Int,
        step: Int,
        format: (Int) -> String,
        get: () -> Int,
        write: (MotionSettings, Int) -> MotionSettings
    ) {
        val titleView = text("", 14f, pal.onSurface)
        parent.addView(titleView, lp(top = 14))
        val seek = SeekBar(this)
        seek.max = (max - min) / step
        seek.progressTintList = ColorStateList.valueOf(pal.primary)
        seek.thumbTintList = ColorStateList.valueOf(pal.primary)
        seek.progressBackgroundTintList = ColorStateList.valueOf(pal.track)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                if (!fromUser) return
                val v = min + value * step
                titleView.text = format(v)
                update(write(s, v))
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        parent.addView(seek, lp(top = 4))
        syncers.add {
            val v = get()
            seek.progress = (v - min) / step
            titleView.text = format(v)
        }
    }

    /** A labelled drop-down. */
    private fun addChoice(
        parent: LinearLayout,
        title: String,
        labels: List<String>,
        getIndex: () -> Int,
        onPick: (Int) -> Unit
    ) {
        parent.addView(text(title, 14f, pal.onSurface), lp(top = 14))
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.backgroundTintList = ColorStateList.valueOf(pal.onSurfaceVariant)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parentView: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing && position != getIndex()) onPick(position)
            }

            override fun onNothingSelected(parentView: AdapterView<*>?) {}
        }
        parent.addView(spinner, lp(top = 2))
        syncers.add { spinner.setSelection(getIndex(), false) }
    }

    private fun styledSwitch(label: String, onChange: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        sw.text = label
        sw.setTextColor(pal.onSurface)
        sw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        sw.minHeight = dp(48)
        val checked = intArrayOf(android.R.attr.state_checked)
        sw.thumbTintList = ColorStateList(arrayOf(checked, intArrayOf()), intArrayOf(pal.onPrimary, pal.outline))
        sw.trackTintList = ColorStateList(arrayOf(checked, intArrayOf()), intArrayOf(pal.primary, pal.track))
        sw.setOnCheckedChangeListener { _, c -> if (!syncing) onChange(c) }
        return sw
    }

    /** A card section header that expands and collapses its content with an animation. */
    private fun expandable(title: String, content: View): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val header = pill("Show $title", TONAL) { }
        content.visibility = View.GONE
        header.setOnClickListener {
            TransitionManager.beginDelayedTransition(rootLayout)
            val show = content.visibility != View.VISIBLE
            content.visibility = if (show) View.VISIBLE else View.GONE
            header.text = (if (show) "Hide " else "Show ") + title
        }
        box.addView(header)
        box.addView(content, lp(top = 12))
        return box
    }

    private fun rebuildThumbs() {
        thumbRow.removeAllViews()
        val ids = ArrayList<String>()
        for (sample in Wallpapers.samples) ids.add(sample.id)
        val custom = Wallpapers.existingCustomId(this)
        if (custom != null) ids.add(custom)

        for (id in ids) {
            val image = ImageView(this)
            image.scaleType = ImageView.ScaleType.CENTER_CROP
            image.outlineProvider = roundOutline(dp(10))
            image.clipToOutline = true
            val bmp = loadThumb(id)
            if (bmp != null) image.setImageBitmap(bmp)

            val frame = FrameLayout(this)
            frame.setPadding(dp(3), dp(3), dp(3), dp(3))
            frame.tag = id
            frame.isClickable = true
            frame.isFocusable = true
            frame.foreground = rippleMask(dp(12).toFloat())
            pressable(frame)
            frame.addView(image, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            frame.setOnClickListener {
                update(s.copy(wallpaperId = id))
                refreshThumbSelection()
            }
            val params = LinearLayout.LayoutParams(0, dp(112), 1f)
            params.setMargins(dp(3), 0, dp(3), 0)
            thumbRow.addView(frame, params)
        }
        refreshThumbSelection()
    }

    private fun refreshThumbSelection() {
        for (i in 0 until thumbRow.childCount) {
            val v = thumbRow.getChildAt(i)
            val selected = v.tag == s.wallpaperId
            val ring = GradientDrawable()
            ring.cornerRadius = dp(12).toFloat()
            ring.setColor(Color.TRANSPARENT)
            ring.setStroke(dp(2), if (selected) pal.primary else Color.TRANSPARENT)
            v.background = ring
        }
    }

    private fun loadThumb(id: String): Bitmap? {
        val source = Wallpapers.openSource(this, id) ?: return null
        return try {
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val h = info.size.height
                val w = info.size.width
                val scale = min(1f, 360f / h)
                decoder.setTargetSize(max(1, (w * scale).roundToInt()), max(1, (h * scale).roundToInt()))
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    // ------------------------------------------------------------------ picking an image (Storage Access Framework)

    @Suppress("DEPRECATION")
    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "image/png", "image/webp"))
        }
        try {
            startActivityForResult(intent, REQ_PICK)
        } catch (e: ActivityNotFoundException) {
            toast("No file picker available on this device")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val appContext = applicationContext
        toast("Importing image...")
        Thread {
            try {
                val id = Wallpapers.importFromUri(appContext, uri)
                runOnUiThread {
                    if (!isDestroyed) {
                        update(s.copy(wallpaperId = id))
                        Wallpapers.cleanupCustom(this, id)
                        rebuildThumbs()
                        toast("Wallpaper imported")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isDestroyed) toast(e.message ?: "Could not import that image")
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ diagnostics (no PC needed)

    private fun showEvents() {
        val header = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
            "${Build.MANUFACTURER} ${Build.MODEL}, build ${Build.VERSION.INCREMENTAL}\n" +
            "app ${BuildConfig.VERSION_NAME}\n" +
            "Lock and unlock the phone a few times, then reopen this screen.\n" +
            "(Events are recorded in debug builds only.)\n\n"
        val body = TextView(this)
        body.text = header + EventLog.dump()
        body.setTextIsSelectable(true)
        body.typeface = Typeface.MONOSPACE
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        body.setPadding(dp(16), dp(8), dp(16), dp(8))
        val scroll = ScrollView(this)
        scroll.addView(body)
        AlertDialog.Builder(this)
            .setTitle("Recent events")
            .setView(scroll)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(ClipboardManager::class.java)
                cm?.setPrimaryClip(ClipData.newPlainText("Subtle Unlock events", body.text))
                toast("Copied to clipboard")
            }
            .setNeutralButton("Clear") { _, _ -> EventLog.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    /** MIUI can pause background processes. This opens the app info page where its limits can be relaxed. */
    private fun openAppInfo() {
        toast("Set Battery saver to \"No restrictions\" and turn Autostart on")
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            toast("Open Settings > Apps > Manage apps > Subtle Unlock Motion")
        }
    }

    // ------------------------------------------------------------------ applying the live wallpaper

    private fun confirmSetWallpaper() {
        AlertDialog.Builder(this)
            .setTitle("Set as live wallpaper")
            .setMessage(
                "Next you will see Android's own wallpaper preview. Your current wallpaper is only " +
                    "replaced if you confirm there.\n\n" +
                    "Your phone may ask for Home screen, Lock screen or both. If it only offers one " +
                    "combined option, both screens change. For the smoothest effect choose Both, " +
                    "or Home screen and set the same picture on the lock screen.\n\n" +
                    "To go back later: Settings > Wallpaper, pick your old wallpaper, or uninstall this app."
            )
            .setPositiveButton("Continue") { _, _ -> launchLivePicker() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchLivePicker() {
        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, UnlockWallpaperService::class.java)
        )
        try {
            startActivity(direct)
            return
        } catch (e: Exception) {
            // Some MIUI builds do not handle the direct intent; fall back to the generic chooser.
        }
        try {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            toast("Pick \"Subtle Unlock Motion\" from the list")
        } catch (e: Exception) {
            toast("Open Settings > Wallpaper > Live wallpapers and choose Subtle Unlock Motion")
        }
    }


    // ------------------------------------------------------------------ small view helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .also { it.topMargin = dp(top) }

    private fun wrapLp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .also { it.topMargin = dp(top) }

    private fun weighted(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.setMargins(dp(3), 0, dp(3), 0)
        return p
    }

    private fun tileLp(): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        p.setMargins(dp(4), 0, dp(4), 0)
        return p
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.isBaselineAligned = false
        return r
    }

    private fun text(str: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = str
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return tv
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(20), dp(20), dp(20), dp(20))
        val bg = GradientDrawable()
        bg.setColor(pal.container)
        bg.cornerRadius = dp(28).toFloat()
        c.background = bg
        return c
    }

    /** Rounded fill with a ripple clipped to the same shape. */
    private fun ripple(fill: Int, radiusPx: Float, strokeColor: Int = 0, strokeWidthPx: Int = 0): RippleDrawable {
        val content = GradientDrawable()
        content.setColor(fill)
        content.cornerRadius = radiusPx
        if (strokeWidthPx > 0) content.setStroke(strokeWidthPx, strokeColor)
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE)
        mask.cornerRadius = radiusPx
        return RippleDrawable(ColorStateList.valueOf(withAlpha(pal.primary, 0x33)), content, mask)
    }

    /** A ripple with no fill (used as a foreground over images). */
    private fun rippleMask(radiusPx: Float): RippleDrawable {
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE)
        mask.cornerRadius = radiusPx
        return RippleDrawable(ColorStateList.valueOf(withAlpha(pal.primary, 0x40)), null, mask)
    }

    /** Subtle scale-down while pressed, on top of the ripple. Does not consume the touch, so clicks still work. */
    private fun pressable(v: View) {
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(150L).start()
            }
            false
        }
    }

    /** A pill-shaped Material button built from a TextView, with ripple and press feedback. */
    private fun pill(label: String, kind: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.minHeight = dp(48)
        t.setPadding(dp(18), dp(10), dp(18), dp(10))
        val r = dp(24).toFloat()
        when (kind) {
            FILLED -> {
                t.setTextColor(pal.onPrimary)
                t.background = ripple(pal.primary, r)
            }
            TONAL -> {
                t.setTextColor(pal.onPrimaryContainer)
                t.background = ripple(pal.primaryContainer, r)
            }
            else -> {
                t.setTextColor(pal.primary)
                t.background = ripple(Color.TRANSPARENT, r, pal.outline, dp(1))
            }
        }
        t.isClickable = true
        t.isFocusable = true
        t.setOnClickListener { onClick() }
        pressable(t)
        return t
    }

    private fun roundOutline(radiusPx: Int): ViewOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx.toFloat())
        }
    }

    private companion object {
        const val REQ_PICK = 4242
        const val FILLED = 0
        const val TONAL = 1
        const val OUTLINED = 2
    }
}
