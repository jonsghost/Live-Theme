package com.subtleunlock.wallpaper

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure-JVM tests of the style logic (no Android runtime needed). */
class PresetsTest {

    /** What a fresh install gets: the v1.3 default look. */
    private fun defaults() = MotionSettings(
        enabled = MotionSettings.DEFAULT_ENABLED,
        offlineMode = false,
        holdLockPose = MotionSettings.DEFAULT_HOLD_LOCK_POSE,
        lockAnimate = MotionSettings.DEFAULT_LOCK_ANIMATE,
        reducedMotion = MotionSettings.DEFAULT_REDUCED_MOTION,
        durationMs = MotionSettings.DEFAULT_DURATION_MS,
        easing = MotionSettings.DEFAULT_EASING,
        direction = MotionSettings.DEFAULT_DIRECTION,
        lock = MotionSettings.DEFAULT_LOCK,
        home = MotionSettings.DEFAULT_HOME,
        drawer = Look(zoomPercent = MotionSettings.DEFAULT_FOLLOW_ZOOM_PERCENT),
        frameCornerDp = MotionSettings.DEFAULT_FRAME_CORNER_DP,
        followLauncher = MotionSettings.DEFAULT_FOLLOW,
        followZoomPercent = MotionSettings.DEFAULT_FOLLOW_ZOOM_PERCENT,
        followSlideDp = MotionSettings.DEFAULT_FOLLOW_SLIDE_DP,
        desktopParallaxEnabled = MotionSettings.DEFAULT_DESKTOP_PARALLAX,
        desktopParallaxStrengthDp = MotionSettings.DEFAULT_DESKTOP_PARALLAX_STRENGTH_DP,
        visibilityFallback = MotionSettings.DEFAULT_VISIBILITY_FALLBACK,
        styleId = "",
        wallpaperId = "asset:test.jpg",
        secondWallpaperId = "",
        appThemeMode = "system",
        appBackgroundMode = "wallpaper",
        backgroundBlurDp = 36,
        backgroundDimPercent = 38,
        accentColor = "system"
    )

    @Test
    fun classicFrameZoomIsExactlyTheV13Default() {
        val d = defaults()
        assertEquals(d, Presets.main[0].transform(d))
        assertEquals("classic", Presets.main[0].id)
        // The accepted v1.3 look: lock zoomed out 5%, plain home, 450 ms soft, drawer zoom -5%.
        assertEquals(-5, d.lock.zoomPercent)
        assertEquals(Look.NONE, d.home)
        assertEquals(450, d.durationMs)
        assertEquals(Easing.SOFT, d.easing)
        assertEquals(-5, d.followZoomPercent)
    }

    @Test
    fun everyPresetProducesADistinctResult() {
        val d = defaults()
        val results = Presets.all.map { it.transform(d) }
        assertEquals("two presets produce identical settings", Presets.all.size, results.toSet().size)
    }

    @Test
    fun presetIdsAreUnique() {
        assertEquals(Presets.all.size, Presets.all.map { it.id }.toSet().size)
    }

    @Test
    fun presetsNeverTouchWallpaperOrUserPreferences() {
        val d = defaults().copy(enabled = false, reducedMotion = true, visibilityFallback = true, wallpaperId = "file:mine.img")
        for (p in Presets.all) {
            val out = p.transform(d)
            assertEquals(p.id, "file:mine.img", out.wallpaperId)
            assertEquals(p.id, false, out.enabled)
            assertEquals(p.id, true, out.reducedMotion)
            assertEquals(p.id, true, out.visibilityFallback)
        }
    }

    @Test
    fun labelNamesTheStyleThenFlagsModification() {
        val d = defaults()
        val blur = Presets.all.first { it.id == "blur_reveal" }
        val applied = blur.transform(d).copy(styleId = "blur_reveal")
        assertEquals("Blur Reveal", Presets.label(applied))

        val modified = applied.copy(lock = applied.lock.copy(blurPercent = 20))
        assertEquals("Custom (modified from Blur Reveal)", Presets.label(modified))

        // Choosing "Custom" with values that happen to equal no preset
        val custom = modified.copy(styleId = "custom")
        assertEquals("Custom", Presets.label(custom))
    }

    @Test
    fun matchingFindsAPresetOnlyWhenEveryValueEquals() {
        val d = defaults()
        assertEquals("classic", Presets.matching(d)?.id)
        assertEquals(null, Presets.matching(d.copy(durationMs = 451)))
    }

    @Test
    fun lockAndHomeLooksAreIndependent() {
        val d = defaults()
        val grayHome = Presets.all.first { it.id == "gray_home" }.transform(d)
        assertEquals(0, grayHome.lock.grayPercent)
        assertEquals(100, grayHome.home.grayPercent)
        val grayLock = Presets.all.first { it.id == "gray_lock" }.transform(d)
        assertEquals(100, grayLock.lock.grayPercent)
        assertEquals(0, grayLock.home.grayPercent)
    }

    @Test
    fun unknownKeysFallBackToSafeDefaults() {
        assertEquals(Direction.UP, Direction.fromKey("bogus"))
        assertEquals(Easing.SOFT, Easing.fromKey(null))
    }

    @Test
    fun boxBlurKeepsAFlatImageFlatAndSpreadsALightPixel() {
        val w = 9
        val h = 7
        val grey = (0xFF shl 24) or (100 shl 16) or (100 shl 8) or 100
        val flat = IntArray(w * h) { grey }
        BlurUtil.boxBlur(flat, w, h, 2)
        assertTrue(flat.all { it == grey })

        val black = 0xFF shl 24
        val img = IntArray(w * h) { black }
        img[3 * w + 4] = (0xFF shl 24) or (255 shl 16) or (255 shl 8) or 255
        BlurUtil.boxBlur(img, w, h, 1)
        val centre = img[3 * w + 4] and 0xFF
        val neighbour = img[3 * w + 5] and 0xFF
        assertTrue("the bright pixel must be dimmed", centre < 255)
        assertTrue("and must spread to its neighbours", neighbour > 0)
        assertNotEquals(centre, 0)
    }

    @Test
    fun blurShrinkFactorIsAPowerOfTwoAndGrowsWithRadius() {
        var last = 0
        for (r in listOf(2f, 6f, 12f, 24f, 40f, 80f)) {
            val f = BlurUtil.factorFor(r)
            assertTrue(f == 2 || f == 4 || f == 8 || f == 16)
            assertTrue(f >= last)
            last = f
        }
    }
}
