package com.subtleunlock.wallpaper

import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.animation.PathInterpolator
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

/**
 * One-shot, time-based driver that moves a value from [from] to [to].
 *
 *  - Frames are requested ONLY while running; nothing is scheduled before start() or after the end.
 *  - Time comes from the monotonic clock (Choreographer's frameTimeNanos / System.nanoTime()).
 *  - The first frame defines t=0, so scheduling latency never eats into the animation.
 *  - Curves are created once. The listener uses primitive parameters: no allocation per frame.
 *
 * Choreographer fallback: on the test POCO M2 Pro (MIUI 14) the Choreographer delivers no frame to
 * the wallpaper process after unlock. If no Choreographer frame has arrived FALLBACK_AFTER_MS after
 * start(), this run is driven by a short Handler loop instead (8 ms ticks; the surface's buffer queue
 * paces it). It is bounded: it ends with the transition and is stopped by cancel().
 *
 * Must be created and used on the main thread.
 */
class TransitionRunner(private val listener: Listener) : Choreographer.FrameCallback {

    interface Listener {
        /** value: current value between from and to (springy easing may briefly pass beyond [to]). Never called with the final value. */
        fun onTransitionFrame(value: Float)

        /** Called once when the run completes normally (not when cancelled). Draw the final frame here. */
        fun onTransitionFinished()
    }

    private val choreographer: Choreographer = Choreographer.getInstance()
    private val handler = Handler(Looper.getMainLooper())
    private val smooth = PathInterpolator(0.2f, 0f, 0f, 1f)
    private val soft = PathInterpolator(0.4f, 0f, 0.2f, 1f)

    private var startNanos = -1L
    private var durationNanos = 1L
    private var usingFallback = false
    private var easing = Easing.SOFT
    private var from = 0f
    private var to = 1f

    var running = false
        private set

    /** True if the current/last run had to be driven by the Handler fallback. */
    var usedFallback = false
        private set

    private val fallbackTick = object : Runnable {
        override fun run() {
            if (!running || !usingFallback) return
            step(System.nanoTime())
            if (running && usingFallback) handler.postDelayed(this, FALLBACK_FRAME_MS)
        }
    }

    private val fallbackKick = Runnable {
        // No Choreographer frame arrived in time: switch this run to the Handler driver.
        if (running && startNanos < 0L) {
            usingFallback = true
            usedFallback = true
            choreographer.removeFrameCallback(this)
            fallbackTick.run()
        }
    }

    /** Starts a new run. Does nothing if one is already running (animations never stack). */
    fun start(durationMs: Long, easing: Easing, from: Float, to: Float) {
        if (running) return
        running = true
        usingFallback = false
        usedFallback = false
        startNanos = -1L
        durationNanos = durationMs.coerceAtLeast(1L) * 1_000_000L
        this.easing = easing
        this.from = from
        this.to = to
        choreographer.postFrameCallback(this)
        handler.postDelayed(fallbackKick, FALLBACK_AFTER_MS)
    }

    /** Stops immediately. No callbacks remain scheduled. onTransitionFinished is NOT invoked. */
    fun cancel() {
        if (!running) return
        running = false
        usingFallback = false
        choreographer.removeFrameCallback(this)
        handler.removeCallbacks(fallbackKick)
        handler.removeCallbacks(fallbackTick)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running || usingFallback) return
        step(frameTimeNanos)
        // step() may have finished or been cancelled by the listener; only then do we stop asking for frames.
        if (running && !usingFallback) choreographer.postFrameCallback(this)
    }

    private fun step(nowNanos: Long) {
        if (startNanos < 0L) startNanos = nowNanos
        val t = (nowNanos - startNanos).toFloat() / durationNanos.toFloat()
        if (t >= 1f) {
            running = false // stop scheduling before notifying
            usingFallback = false
            handler.removeCallbacks(fallbackKick)
            handler.removeCallbacks(fallbackTick)
            listener.onTransitionFinished()
            return
        }
        val e = ease(if (t < 0f) 0f else t)
        listener.onTransitionFrame(from + (to - from) * e)
    }

    private fun ease(t: Float): Float = when (easing) {
        Easing.SMOOTH -> smooth.getInterpolation(t)
        Easing.SOFT -> soft.getInterpolation(t)
        Easing.SPRING -> {
            // Underdamped spring released from rest (damping ratio 0.55): overshoots ~13%, residual <0.1% at t=1.
            val x = exp(-SPRING_A * t) * (cos(SPRING_B * t) + SPRING_K * sin(SPRING_B * t))
            1f - x
        }
    }

    private companion object {
        const val FALLBACK_AFTER_MS = 48L
        const val FALLBACK_FRAME_MS = 8L
        const val SPRING_A = 5.5f
        const val SPRING_B = 8.352f
        const val SPRING_K = 0.6585f
    }
}
