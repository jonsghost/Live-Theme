package com.subtleunlock.wallpaper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import kotlin.math.min

/**
 * A miniature phone-shaped preview that uses the very same renderer, poses and easing as the live
 * wallpaper. Sizes are scaled by (preview width / real screen width), so what you see is proportional
 * to what the real wallpaper does.
 */
class PreviewView(context: Context) : View(context), TransitionRunner.Listener {

    private val renderer = WallpaperRenderer(context)
    private val runner = TransitionRunner(this)

    private var settings: MotionSettings = SettingsStore.load(context)
    private var progress = 1f
    private var poseTarget = 1f
    private var needsConfigure = true
    private var ready = false

    init {
        val radius = 22f * resources.displayMetrics.density
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
    }

    fun applySettings(s: MotionSettings) {
        settings = s
        runner.cancel()
        progress = 1f
        needsConfigure = true
        invalidate()
    }

    /** Lock screen -> home: the picture starts in the LOCK pose and glides to HOME. */
    fun playUnlock() = playPose(0f, 1f)

    /** Home -> lock screen: glides into the LOCK pose and stays there until the next demo. */
    fun playLock() = playPose(1f, 0f)

    /** Shows the lock look (progress 0) or the home look (progress 1) instantly, without animating. */
    fun showPose(p: Float) {
        if (!prepare()) return
        progress = p
        invalidate()
    }

    private fun playPose(from: Float, to: Float) {
        if (!prepare()) return
        poseTarget = to
        progress = from
        runner.start(settings.durationMs.toLong(), settings.easing, from, to)
        invalidate()
    }

    private fun prepare(): Boolean {
        if (width <= 0 || height <= 0) return false
        if (needsConfigure) configureNow()
        if (!ready) return false
        runner.cancel()
        return true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        runner.cancel()
        progress = 1f
        needsConfigure = true
    }

    override fun onDraw(canvas: Canvas) {
        if (needsConfigure) configureNow()
        if (ready) renderer.draw(canvas, progress, 0f) else canvas.drawColor(Color.BLACK)
    }

    override fun onDetachedFromWindow() {
        runner.cancel()
        renderer.release()
        needsConfigure = true
        super.onDetachedFromWindow()
    }

    override fun onTransitionFrame(value: Float) {
        progress = value
        invalidate()
    }

    override fun onTransitionFinished() {
        progress = poseTarget
        invalidate()
    }

    private fun configureNow() {
        needsConfigure = false
        val dm = resources.displayMetrics
        val realScreenWidthPx = min(dm.widthPixels, dm.heightPixels).toFloat()
        val pxPerDp = dm.density * (width / realScreenWidthPx)
        ready = renderer.configure(width, height, settings, pxPerDp)
    }

}
