plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.subtleunlock.wallpaper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.subtleunlock.wallpaper"
        // 28 = Android 9. ImageDecoder (EXIF-aware, decode-time downscale) needs API 28.
        minSdk = 28
        // Deliberately 31 (Android 12, the target phone). Behaviour changes of API 32-34
        // (e.g. exported-receiver flags, foreground-service rules) are not needed and
        // staying at 31 keeps behaviour identical to what MIUI 12.5/13 on Android 12 expects.
        targetSdk = 31
        versionCode = 7
        versionName = "0.1.5"
    }

    buildTypes {
        debug {
            // BuildConfig.DEBUG enables the (cheap) "SubtleUnlock" logcat diagnostics.
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the release APK can be sideloaded with adb.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    // The app itself has no third-party dependencies (the Kotlin stdlib is added by the Kotlin plugin).
    // JUnit is used only by the local unit tests in app/src/test and is not packaged in the APK.
    testImplementation("junit:junit:4.13.2")
}
