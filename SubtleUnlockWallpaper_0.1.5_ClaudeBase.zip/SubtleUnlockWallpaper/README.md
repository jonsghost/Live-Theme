# Live-Theme

A native Android live wallpaper app that turns a still photo into a subtle animated wallpaper. The app focuses on restrained lock/unlock movement, launcher interactions and user-controlled visual effects rather than exaggerated motion.

> **Development build:** `0.1.5` — internal alpha iteration 5. Alpha builds are not public releases.

## Current feature set

- Independent **Lock screen**, **Home screen** and **App drawer** looks.
- Per-look Zoom, Grayscale, Blur and Fade effects. Each effect can be enabled/disabled and tuned from its three-dot control.
- Optional second photo for cross-fading between images.
- Existing lock/unlock transition engine, easing, reduced-motion support and launcher app-drawer depth response.
- Separate horizontal home-screen page parallax using launcher wallpaper offsets. No gyroscope or accelerometer is used.
- App background derived from the selected wallpaper, with adjustable blur and dimming; System/Light/Dark appearance and accent-colour choices.
- Live / Offline / Disconnected status. Offline pauses wallpaper motion while retaining the currently rendered frame.
- Diagnostics for reviewing unlock events and frame timing.

## Motion behaviour

- **Lock/unlock:** the wallpaper blends between the configured lock and home looks. The existing event-driven transition engine is retained.
- **App drawer / app opening:** the launcher's `onZoomChanged` signal controls the separate app-drawer look.
- **Home-screen page swipe:** `onOffsetsChanged` controls only the horizontal desktop parallax. This does not replace the app-drawer callback. The launcher must provide changing horizontal offsets; some launchers report no usable horizontal page range.
- Effects are intended to remain subtle. Blur and image preparation happen when settings or images change, not continuously per frame.

### Depth parallax status

The current horizontal page parallax is a bounded 2D translation of the prepared wallpaper. A depth-estimation model (including the previously discussed ZipDepth candidate) is **not bundled or integrated** in this build. No AI depth effect is claimed. Any future model integration must be validated for Android runtime compatibility, model licence, memory use and preparation time before release.

## Image support

- Still images only (JPEG, PNG and WebP through Android's document picker).
- GIF and video wallpapers are not supported or planned for this version.
- A second still image can be selected for the Fade effect.

## Build with GitHub Actions

The workflow at `.github/workflows/android.yml`:

1. Finds the Android project in the repository, or extracts a project ZIP if one is present.
2. Installs JDK 17 and Gradle 8.2.
3. Runs `gradle assembleDebug` and `gradle testDebugUnitTest`.
4. Uploads the debug APK as a GitHub Actions artifact.

The source project currently does not contain `gradlew`, `gradlew.bat` or `gradle-wrapper.jar`; the workflow therefore installs and invokes Gradle directly. A future source cleanup should add a complete Gradle Wrapper.

## Version convention

- `0.1.5`: fifth private alpha iteration (not publicly released).
- `0.1`: first beta release.
- `1.0`: first stable release.

## Compatibility notes

The project targets Android and retains the original Android 12 / POCO M2 Pro compatibility work. Horizontal page parallax depends on launcher offset callbacks, which vary by launcher and device. If the launcher does not expose horizontal offsets, lock/unlock and app-drawer effects remain available but desktop-page parallax cannot operate on that launcher.

## Licensing

The project is distributed under the MIT License. Third-party dependencies and any future model files/assets remain subject to their own licences.
