package com.subtleunlock.wallpaper

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Wallpaper ids are strings stored in preferences:
 *   "asset:<file>"  -> bundled sample in assets/wallpapers/
 *   "file:<name>"   -> user image copied into app-private storage (filesDir/wallpapers/)
 */
object Wallpapers {

    data class Sample(val id: String, val label: String)

    val samples = listOf(
        Sample("asset:midnight_ridge.jpg", "Midnight ridge"),
        Sample("asset:soft_aurora.jpg", "Soft aurora"),
        Sample("asset:alpine_dawn.jpg", "Alpine dawn")
    )

    const val DEFAULT_ID = "asset:midnight_ridge.jpg"

    private const val MAX_IMPORT_BYTES = 80L * 1024L * 1024L
    private const val CUSTOM_PREFIX = "custom_"

    private fun dir(context: Context): File =
        File(context.filesDir, "wallpapers").also { it.mkdirs() }

    /** Returns null when the id does not point to something readable. */
    fun openSource(context: Context, id: String): ImageDecoder.Source? {
        return when {
            id.startsWith("asset:") ->
                ImageDecoder.createSource(context.assets, "wallpapers/" + File(id.removePrefix("asset:")).name)
            id.startsWith("file:") -> {
                val f = File(dir(context), File(id.removePrefix("file:")).name)
                if (f.isFile) ImageDecoder.createSource(f) else null
            }
            else -> null
        }
    }

    fun isCustom(id: String): Boolean = id.startsWith("file:")

    /**
     * Copies the picked image into private storage unchanged (no re-encoding, no filters) and
     * verifies that Android can decode it. Returns the new wallpaper id. Blocking: call off the
     * main thread. Throws IOException with a user-presentable message on failure.
     */
    @Throws(IOException::class)
    fun importFromUri(context: Context, uri: Uri): String {
        val folder = dir(context)
        val tmp = File(folder, "import.tmp")
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Could not open that image.")
            input.use { src ->
                FileOutputStream(tmp).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = src.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > MAX_IMPORT_BYTES) throw IOException("That image is larger than 80 MB.")
                        out.write(buffer, 0, n)
                    }
                }
            }

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(tmp.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                throw IOException("That file is not a supported image (use JPEG, PNG or WebP).")
            }

            val name = CUSTOM_PREFIX + System.currentTimeMillis() + ".img"
            if (!tmp.renameTo(File(folder, name))) throw IOException("Could not save the image.")
            return "file:$name"
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    /** Deletes imported images other than [keepId] (call after the preference points at keepId). */
    fun cleanupCustom(context: Context, keepId: String) = cleanupCustom(context, setOf(keepId))

    fun cleanupCustom(context: Context, keepIds: Set<String>) {
        val keepNames = keepIds.filter { isCustom(it) }.map { File(it.removePrefix("file:")).name }.toSet()
        dir(context).listFiles()?.forEach { f ->
            if (f.name.startsWith(CUSTOM_PREFIX) && f.name !in keepNames) f.delete()
        }
    }

    /** Id of the currently stored custom image, or null. */
    fun existingCustomId(context: Context): String? {
        val f = dir(context).listFiles()
            ?.filter { it.name.startsWith(CUSTOM_PREFIX) }
            ?.maxByOrNull { it.lastModified() }
        return f?.let { "file:" + it.name }
    }
}
