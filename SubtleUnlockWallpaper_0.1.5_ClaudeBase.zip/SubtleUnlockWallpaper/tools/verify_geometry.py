#!/usr/bin/env python3
"""
Build-time SIMULATION of WallpaperRenderer (v1.4): a faithful Python port of configure() and draw()'s
geometry. It is NOT a device test. It checks:
  A. PARITY: with a plain HOME look, v1.4 computes exactly the same decode size, base scale and rest
     position as v1.3, for random v1.3-style settings. (The accepted animation is unchanged.)
  B. COVERAGE: for random lock AND home looks (zoom / slide / tilt), screens and image shapes, the
     transformed picture covers all four screen corners at every step of lock->home, home->lock
     (incl. springy overshoot) and launcher-follow. No edge ever shows.
  C. The plain HOME look is drawn at base scale, integer position, no tilt.
Grayscale, blur, fade and frame do not change geometry (frame/fade/grayscale draw over or inside the
covered area), so they are not part of this check.
"""
import math, random, itertools

def kround(x): return int(math.floor(x + 0.5))      # Kotlin Float.roundToInt(): ties toward +inf
DIRS = {"up": (0, 1), "down": (0, -1), "left": (1, 0), "right": (-1, 0),
        "up_left": (.7071, .7071), "up_right": (-.7071, .7071),
        "down_left": (.7071, -.7071), "down_right": (-.7071, -.7071)}

def decode_and_scale(W, H, aw, ah, iw, ih):
    sc = max(aw / iw, ah / ih)
    bw, bh = (max(1, math.ceil(iw * sc)), max(1, math.ceil(ih * sc))) if sc < 1 else (iw, ih)
    base = max(aw / bw, ah / bh)
    return bw, bh, base, kround((W - bw * base) / 2), kround((H - bh * base) / 2)

def configure_v13(W, H, pxdp, s, iw, ih):            # v1.3 formulas, plain home
    ovf = 1.15 if s["easing"] == "spring" else 1.0
    dpose = s["slide"] * pxdp
    dfol = s["fslide"] * pxdp if s["follow"] else 0.0
    reach = max(dpose, dfol) * ovf
    ux, uy = DIRS[s["dir"]]
    rx, ry = reach * abs(ux), reach * abs(uy)
    rad = math.radians(s["tilt"] / 10 * ovf); ca, sa = math.cos(rad), math.sin(rad)
    rotW = W * ca + H * sa + 2.0 * (rx * ca + ry * sa)
    rotH = W * sa + H * ca + 2.0 * (rx * sa + ry * ca)
    zp = s["zoom"] / 100; zf = s["fzoom"] / 100 if s["follow"] else 0.0
    zneg = min(0.0, min(zp * ovf, zf)); head = 1 / (1 + zneg)
    aw, ah = math.ceil((rotW + 2.0) * head), math.ceil((rotH + 2.0) * head)
    return (aw, ah) + decode_and_scale(W, H, aw, ah, iw, ih)

def configure_v14(W, H, pxdp, s, iw, ih):
    lock, home = s["lock"], s["home"]
    ovf = 1.15 if s["easing"] == "spring" else 1.0
    def bound(a, b):
        big, small = max(a, b), min(a, b)
        return big * ovf + small * (ovf - 1) if ovf > 1 else big
    ls, hs = lock["slide"] * pxdp, home["slide"] * pxdp
    dfol = s["fslide"] * pxdp if s["follow"] else 0.0
    reach = max(bound(ls, hs), dfol * ovf)
    ux, uy = DIRS[s["dir"]]
    rx, ry = reach * abs(ux), reach * abs(uy)
    rad = math.radians(bound(lock["tilt"] / 10, home["tilt"] / 10)); ca, sa = math.cos(rad), math.sin(rad)
    rotW = W * ca + H * sa + 2.0 * (rx * ca + ry * sa)
    rotH = W * sa + H * ca + 2.0 * (rx * sa + ry * ca)
    zl, zh = lock["zoom"] / 100, home["zoom"] / 100
    zf = s["fzoom"] / 100 if s["follow"] else 0.0
    kmin = min(1.0, min(1 + zl, 1 + zh))
    kmin = min(kmin, 1 + (zh + (zl - zh) * ovf))
    kmin = min(kmin, (1 + zh) * (1 + zf))
    head = 1 / kmin
    aw, ah = math.ceil((rotW + 2.0) * head), math.ceil((rotH + 2.0) * head)
    bw, bh, base, rtx, rty = decode_and_scale(W, H, aw, ah, iw, ih)
    return dict(aw=aw, ah=ah, bw=bw, bh=bh, base=base, rtx=rtx, rty=rty, ux=ux, uy=uy, ls=ls, hs=hs,
                dfol=dfol, zl=zl, zh=zh, zf=zf, tl=lock["tilt"] / 10, th=home["tilt"] / 10, kfloor=1 / head)

def transform(c, progress, follow):
    inv = 1 - progress
    mix = lambda h, l: h + (l - h) * inv
    k = c["base"] * (1 + mix(c["zh"], c["zl"])) * (1 + c["zf"] * follow)
    k = max(k, c["base"] * c["kfloor"])
    slide = mix(c["hs"], c["ls"]) - c["dfol"] * follow
    tx = c["rtx"] + (c["bw"] * c["base"] - c["bw"] * k) / 2 + c["ux"] * slide
    ty = c["rty"] + (c["bh"] * c["base"] - c["bh"] * k) / 2 + c["uy"] * slide
    return k, tx, ty, math.radians(mix(c["th"], c["tl"]))

def covers(c, W, H, k, tx, ty, ang):
    cx, cy = c["bw"] * k / 2, c["bh"] * k / 2
    pts = []
    for (x, y) in ((0, 0), (c["bw"] * k, 0), (c["bw"] * k, c["bh"] * k), (0, c["bh"] * k)):
        dx, dy = x - cx, y - cy
        pts.append((cx + dx * math.cos(ang) - dy * math.sin(ang) + tx, cy + dx * math.sin(ang) + dy * math.cos(ang) + ty))
    worst = 1e9
    for (px, py) in ((0, 0), (W, 0), (W, H), (0, H)):
        for i in range(4):
            ax, ay = pts[i]; bx, by = pts[(i + 1) % 4]
            worst = min(worst, ((bx - ax) * (py - ay) - (by - ay) * (px - ax)) / math.hypot(bx - ax, by - ay))
    return worst

def spring(t): return 1 - math.exp(-5.5 * t) * (math.cos(8.352 * t) + 0.6585 * math.sin(8.352 * t))

def check(W, H, pxdp, s, iw, ih):
    c = configure_v14(W, H, pxdp, s, iw, ih)
    e = spring if s["easing"] == "spring" else (lambda t: t)
    worst = 1e9
    for i in range(241):
        p = e(i / 240)
        worst = min(worst, covers(c, W, H, *transform(c, p, 0.0)), covers(c, W, H, *transform(c, 1 - p, 0.0)),
                    covers(c, W, H, *transform(c, 1.0, i / 240)))
    if s["home"] == dict(zoom=0, slide=0, tilt=0):   # C: plain HOME look is crisp
        k, tx, ty, ang = transform(c, 1.0, 0.0)
        assert abs(k - c["base"]) < 1e-9 and ang == 0 and tx == int(tx) and ty == int(ty)
    return worst

screens = [(1080, 2400, 2.2), (1080, 2400, 2.75), (720, 1600, 2.0), (1440, 3200, 3.5)]
images = [(1440, 3200), (3000, 4000), (4000, 3000), (800, 800), (8000, 2000), (12000, 9000), (600, 1300)]
random.seed(11)
NONE = dict(zoom=0, slide=0, tilt=0)

# A. parity with v1.3 (plain home look)
mism = 0
for _ in range(1200):
    s13 = dict(zoom=random.randint(-10, 10), slide=random.randint(0, 48), dir=random.choice(list(DIRS)),
               tilt=random.randint(0, 30), easing=random.choice(["smooth", "soft", "spring"]),
               follow=random.random() < .7, fzoom=random.randint(-10, 10), fslide=random.randint(0, 48))
    # v1.3 also headroom'd positive-zoom + spring identically only when no overshoot term applies; compare as shipped
    s14 = dict(lock=dict(zoom=s13["zoom"], slide=s13["slide"], tilt=s13["tilt"]), home=NONE, dir=s13["dir"],
               easing=s13["easing"], follow=s13["follow"], fzoom=s13["fzoom"], fslide=s13["fslide"])
    W, H, d = random.choice(screens); iw, ih = random.choice(images)
    a = configure_v13(W, H, d, s13, iw, ih); c = configure_v14(W, H, d, s14, iw, ih)
    b = (c["aw"], c["ah"], c["bw"], c["bh"], c["base"], c["rtx"], c["rty"])
    if tuple(a) != b:
        mism += 1
        if mism <= 3: print("PARITY DIFF", s13, a, b)
print(f"A. parity with v1.3 geometry (1200 random settings, plain home look): {'IDENTICAL' if mism == 0 else str(mism) + ' DIFFER'}")

# B. coverage with non-plain looks on both states
fails, n, tight = 0, 0, 1e9
for _ in range(2500):
    s = dict(lock=dict(zoom=random.randint(-10, 10), slide=random.randint(0, 48), tilt=random.randint(0, 30)),
             home=dict(zoom=random.randint(-10, 10), slide=random.randint(0, 48), tilt=random.randint(0, 30)) if random.random() < .6 else NONE,
             dir=random.choice(list(DIRS)), easing=random.choice(["smooth", "soft", "spring"]),
             follow=random.random() < .7, fzoom=random.randint(-10, 10), fslide=random.randint(0, 48))
    W, H, d = random.choice(screens); iw, ih = random.choice(images)
    w = check(W, H, d, s, iw, ih); n += 1; tight = min(tight, w)
    if w < -1e-6:
        fails += 1
        if fails <= 3: print("FAIL", (W, H, d), (iw, ih), s, w)
print(f"B. coverage: {n} random lock/home looks x screens x images: failures {fails}; "
      f"smallest corner-to-edge distance {tight:.3f}px (>= 0 means no edge ever visible)")

# D. desktop-page parallax is a separate post-rotation horizontal translation. The extra decode
# margin must cover both ends while offset=0 retains the non-parallax resting scale and position.
def configure_v15(W, H, pxdp, s, iw, ih):
    lock, home = s["lock"], s["home"]
    ovf = 1.15 if s["easing"] == "spring" else 1.0
    def bound(a, b):
        big, small = max(a, b), min(a, b)
        return big * ovf + small * (ovf - 1) if ovf > 1 else big
    ls, hs = lock["slide"] * pxdp, home["slide"] * pxdp
    dfol = s["fslide"] * pxdp if s["follow"] else 0.0
    reach = max(bound(ls, hs), dfol * ovf)
    ux, uy = DIRS[s["dir"]]
    rx, ry = reach * abs(ux), reach * abs(uy)
    rad = math.radians(max(bound(lock["tilt"] / 10, home["tilt"] / 10), s["dtilt"] / 10 * ovf if s["follow"] else 0))
    ca, sa = math.cos(rad), math.sin(rad)
    rotW = W * ca + H * sa + 2.0 * (rx * ca + ry * sa)
    rotH = W * sa + H * ca + 2.0 * (rx * sa + ry * ca)
    zl, zh = lock["zoom"] / 100, home["zoom"] / 100
    zd = s["fzoom"] / 100 if s["follow"] else 0.0
    kmin = min(1.0, 1 + zl, 1 + zh, 1 + zd,
               1 + (zh + (zh - zl) * (ovf - 1)),
               1 + (zd + (zd - zl) * (ovf - 1)),
               1 + (zh + (zl - zh) * ovf), 1 + (zd + (zl - zd) * ovf))
    head = 1 / kmin
    base_aw = math.ceil((rotW + 2.0) * head)
    desktop_px = s["desktop_dp"] * pxdp if s["desktop"] else 0.0
    aw = base_aw
    ah = math.ceil((rotH + 2.0) * head)
    original_bw, original_bh, base, _, _ = decode_and_scale(W, H, aw, ah, iw, ih)
    bleed_x = math.ceil(desktop_px * head / base) + 5 if desktop_px > 0 else 0
    vertical_reach = desktop_px * abs(math.tan(rad))
    bleed_y = math.ceil(vertical_reach * head / base) + 5 if vertical_reach > 0 else 0
    bw, bh = original_bw + 2 * bleed_x, original_bh + 2 * bleed_y
    rtx = kround((W - original_bw * base) / 2 - bleed_x * base)
    rty = kround((H - original_bh * base) / 2 - bleed_y * base)
    return dict(aw=aw, ah=ah, bw=bw, bh=bh, base=base, rtx=rtx, rty=rty,
                ux=ux, uy=uy, ls=ls, hs=hs, dfol=dfol, zl=zl, zh=zh, zd=zd,
                tl=lock["tilt"] / 10, th=home["tilt"] / 10, td=s["dtilt"] / 10,
                kfloor=1 / head, desktop_px=desktop_px)

def transform_v15(c, progress, follow, desktop_offset):
    inv = 1 - progress
    mix = lambda h, l: h + (l - h) * inv
    home_drawer_zoom = c["zh"] + (c["zd"] - c["zh"]) * follow
    k = max(c["base"] * (1 + mix(home_drawer_zoom, c["zl"])), c["base"] * c["kfloor"])
    slide = mix(c["hs"] - c["dfol"] * follow, c["ls"])
    tx = c["rtx"] + (c["bw"] * c["base"] - c["bw"] * k) / 2 + c["ux"] * slide - desktop_offset * c["desktop_px"]
    ty = c["rty"] + (c["bh"] * c["base"] - c["bh"] * k) / 2 + c["uy"] * slide
    angle = math.radians(mix(c["th"] + (c["td"] - c["th"]) * follow, c["tl"]))
    return k, tx, ty, angle

fails, n, tight = 0, 0, 1e9
for _ in range(1800):
    s = dict(lock=dict(zoom=random.randint(-10, 10), slide=random.randint(0, 48), tilt=random.randint(0, 30)),
             home=dict(zoom=random.randint(-10, 10), slide=random.randint(0, 48), tilt=random.randint(0, 30)) if random.random() < .5 else NONE,
             dir=random.choice(list(DIRS)), easing=random.choice(["smooth", "soft", "spring"]),
             follow=random.random() < .7, fzoom=random.randint(-10, 10), fslide=random.randint(0, 48),
             dtilt=random.randint(0, 30), desktop=True, desktop_dp=random.randint(0, 24))
    W, H, d = random.choice(screens); iw, ih = random.choice(images)
    c = configure_v15(W, H, d, s, iw, ih)
    e = spring if s["easing"] == "spring" else (lambda t: t)
    for i in range(81):
        p = e(i / 80)
        for f in ((0.0, 1.0) if s["follow"] else (0.0,)):
            for offset in (-1.0, 0.0, 1.0):
                worst = covers(c, W, H, *transform_v15(c, p, f, offset))
                n += 1; tight = min(tight, worst)
                if worst < -1e-6:
                    fails += 1
                    if fails <= 3: print("PARALLAX COVERAGE FAIL", (W,H,d), (iw,ih), s, p, f, offset, worst)
                    break
            if fails: break
        if fails: break
    if fails: break
print(f"D. desktop parallax coverage: {n} transformed frames checked; failures {fails}; minimum edge margin {tight:.3f}px")
