package com.subtleunlock.wallpaper

import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/** Engine states. UNLOCK_TRANSITION means "a lock or unlock transition is running". RESET is transient. */
internal enum class EngineState { STATIC, UNLOCK_TRANSITION, INVISIBLE, RESET }

/** A second unlock signal within this window is treated as a duplicate of the first. */
private const val DEBOUNCE_MS = 1200L

/** An unlock signal that arrives while the wallpaper is hidden is remembered this long. */
private const val PENDING_TTL_MS = 1500L

/** If the first animation frame arrives later than this after the trigger, the moment has passed: skip the motion. */
private const val STALE_START_MS = 600L

/** Debug diagnostics: if no frame was drawn this long after a transition started, log why. */
private const val WATCHDOG_MS = 700L

/** A progress value at or above this means "the HOME pose is on the surface". */
private const val HOME_EPS = 0.999f

/**
 * Live wallpaper with two poses and short transitions between them.
 *
 *  - HOME pose: the untouched picture, with optional horizontal desktop-page parallax driven by
 *    launcher wallpaper offsets. App-drawer/app-open zoom callbacks are ignored.
 *  - LOCK pose: the picture zoomed out / slid / tilted / dimmed. Shown while the lock screen is up.
 *    Waking to the lock screen glides HOME -> LOCK; unlocking glides LOCK -> HOME. Since the unlock
 *    starts from what is already on screen, there is no snap at the start.
 *
 * What this can and cannot do (see README): it reacts to the public unlock signal
 * (ACTION_USER_PRESENT), to wallpaper visibility and to horizontal launcher page-offset callbacks.
 * It cannot hook into or change the system's own keyguard animation; the movement is drawn by this
 * wallpaper, around the same moment.
 *
 * No foreground service, no polling, no sensors. Frames are drawn only during a transition (a
 * bounded ~0.5 s) or in response to a launcher callback.
 */
class UnlockWallpaperService : WallpaperService() {

    private val engines = ArrayList<UnlockEngine>()

    override fun onCreateEngine(): Engine = UnlockEngine()

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE ||
            level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
        ) {
            // Free the decoded bitmap of hidden engines; it is re-decoded the next time they are shown.
            for (e in ArrayList(engines)) e.trimIfHidden()
        }
    }

    private inner class UnlockEngine : Engine(), TransitionRunner.Listener {

        private val ctx: Context = this@UnlockWallpaperService
        private val handler = Handler(Looper.getMainLooper())
        private val prefs: SharedPreferences = SettingsStore.prefs(ctx)
        private val renderer = WallpaperRenderer(ctx)
        private val runner = TransitionRunner(this)
        private val keyguard: KeyguardManager? = ctx.getSystemService(KeyguardManager::class.java)
        private val power: PowerManager? = ctx.getSystemService(PowerManager::class.java)

        private var state = EngineState.INVISIBLE
        private var engineVisible = false
        private var surfaceReady = false
        private var surfW = 0
        private var surfH = 0
        private var settings: MotionSettings = SettingsStore.load(ctx)

        /** What is on the surface: pose progress (0 = LOCK, 1 = HOME) and launcher follow amount. */
        private var progress = 1f
        private var parallaxAmt = 0f

        /** Where the running transition is heading (0 = LOCK pose, 1 = HOME pose). */
        private var transitionTarget = 1f

        /** Current horizontal home-screen page position (0..1; 0.5 is the centre page). */
        private var launcherXOffset = 0.5f
        private var configured = false
        private var zoomEvents = 0
        private var lastZoomLogAt = 0L
        private var lastOffsetLogAt = 0L

        private var interactive = true
        private var hiddenWhileLockedOrOff = false
        private var pendingUntil = 0L
        private var lastTriggerAt = -1_000_000L
        private var useHardwareCanvas = true
        private var receiverRegistered = false

        // Debug-only frame statistics.
        private var frames = 0
        private var maxGapMs = 0L
        private var lastFrameNs = 0L
        private var maxDrawMs = 0L
        private var requestedNs = 0L
        private var firstFrameDelayMs = -1L
        private var watchdogDueAt = 0L

        /** Debug only: logs whether the main thread is alive when a transition got no frame. */
        private val watchdog = Runnable {
            if (runner.running && frames == 0) {
                val lateBy = SystemClock.uptimeMillis() - watchdogDueAt
                Dbg.d {
                    "WATCHDOG: no frame ${WATCHDOG_MS}ms after start. This check ran ${lateBy}ms late " +
                        "(late = main thread blocked/frozen; on time = thread alive but no vsync). " +
                        "fallbackDriver=${runner.usedFallback}"
                }
            }
        }

        // ---------------------------------------------------------------- settings changes

        private val applySettingsRunnable = Runnable { applySettings() }

        /** Held in a field: SharedPreferences only keeps a weak reference to listeners. */
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            // Coalesce bursts of changes (e.g. a preset) into one reload.
            handler.removeCallbacks(applySettingsRunnable)
            handler.postDelayed(applySettingsRunnable, 60L)
        }

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_USER_PRESENT -> onUnlockSignal("USER_PRESENT")
                    Intent.ACTION_SCREEN_OFF -> onScreenOff()
                    Intent.ACTION_SCREEN_ON -> onScreenOn()
                }
            }
        }

        // ---------------------------------------------------------------- engine lifecycle

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            engines.add(this)
            prefs.registerOnSharedPreferenceChangeListener(prefsListener)

            interactive = power?.isInteractive ?: true
            hiddenWhileLockedOrOff = !interactive || keyguard?.isKeyguardLocked == true

            if (!isPreview) {
                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_USER_PRESENT)
                    addAction(Intent.ACTION_SCREEN_OFF)
                    addAction(Intent.ACTION_SCREEN_ON)
                }
                ctx.registerReceiver(receiver, filter)
                receiverRegistered = true
            }
            if (!isPreview) setOffsetNotificationsEnabled(true) // horizontal home-screen page navigation
            Dbg.d { "engine created preview=$isPreview interactive=$interactive locked=${keyguard?.isKeyguardLocked}" }
        }

        override fun onDestroy() {
            cancelRun("engine destroyed")
            handler.removeCallbacksAndMessages(null)
            prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
            if (receiverRegistered) {
                try {
                    ctx.unregisterReceiver(receiver)
                } catch (e: IllegalArgumentException) {
                    // already unregistered
                }
                receiverRegistered = false
            }
            renderer.release()
            engines.remove(this)
            state = EngineState.INVISIBLE
            Dbg.d { "engine destroyed" }
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            val sizeChanged = width != surfW || height != surfH
            val wasReady = surfaceReady
            surfW = width
            surfH = height
            surfaceReady = true
            if (sizeChanged) configured = false
            Dbg.d { "surface ${width}x$height changed=$sizeChanged visible=$engineVisible density=${ctx.resources.displayMetrics.density}" }
            if (!engineVisible) return
            // A same-size notification must not interrupt a running transition.
            if (sizeChanged || !wasReady) {
                cancelRun("surface resized")
                state = EngineState.STATIC
                showRestFrameAndHandlePending()
            }
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder?) {
            super.onSurfaceRedrawNeeded(holder)
            if (engineVisible && surfaceReady) {
                ensureConfigured()
                drawFrame(progress, parallaxAmt)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            surfaceReady = false
            cancelRun("surface destroyed")
            state = if (engineVisible) EngineState.STATIC else EngineState.INVISIBLE
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            engineVisible = visible
            Dbg.d { "visibility=$visible state=$state surface=$surfaceReady locked=${keyguard?.isKeyguardLocked} interactive=$interactive progress=$progress" }

            if (!visible) {
                // INVISIBLE: no callbacks, no drawing. The bitmap is kept so showing again is instant.
                cancelRun("hidden")
                hiddenWhileLockedOrOff = !interactive || keyguard?.isKeyguardLocked == true
                state = EngineState.INVISIBLE
                return
            }
            state = EngineState.STATIC
            if (surfaceReady) showRestFrameAndHandlePending()
        }

        /** Horizontal home-screen page movement only. App-drawer/app-open zoom is intentionally ignored. */
        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset)
            if (isPreview || !xOffset.isFinite()) return
            launcherXOffset = xOffset.coerceIn(0f, 1f)
            if (!settings.enabled || !settings.desktopParallaxEnabled) return
            if (!engineVisible || !surfaceReady || runner.running) return
            if (progress < HOME_EPS || !ensureConfigured()) return
            drawNow(1f, currentParallax())
            if (BuildConfig.DEBUG) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastOffsetLogAt > 500L) {
                    lastOffsetLogAt = now
                    Dbg.d { "desktop offset x=$launcherXOffset step=$xOffsetStep parallax=${currentParallax()}" }
                }
            }
        }

        fun trimIfHidden() {
            if (!engineVisible) {
                configured = false
                renderer.release()
                Dbg.d { "bitmap released (trim)" }
            }
        }

        // ---------------------------------------------------------------- signals

        private fun holdPose(): Boolean = settings.enabled && settings.holdLockPose

        private fun currentParallax(): Float {
            if (!settings.enabled || !settings.desktopParallaxEnabled) return 0f
            return ((launcherXOffset - 0.5f) * 2f).coerceIn(-1f, 1f)
        }

        /** The wallpaper is on screen with a valid surface: draw the right pose, then maybe animate. */
        private fun showRestFrameAndHandlePending() {
            ensureConfigured()
            val now = SystemClock.elapsedRealtime()
            val locked = keyguard?.isKeyguardLocked == true

            if (pendingUntil > now) {
                // The unlock signal arrived while we were hidden: play it now that we are visible.
                pendingUntil = 0L
                hiddenWhileLockedOrOff = false
                drawNow(progress, 0f)
                startUnlock("pending-unlock")
                return
            }
            pendingUntil = 0L

            if (holdPose() && locked) {
                // Lock screen is up: rest in the LOCK pose.
                hiddenWhileLockedOrOff = true
                if (progress >= HOME_EPS && settings.lockAnimate) {
                    drawNow(1f, 0f) // what the screen showed before it went off
                    startTransition(1f, 0f, "lock-screen")
                } else {
                    drawNow(0f, 0f)
                }
                return
            }

            // HOME pose (unlocked, or the lock pose is switched off)
            drawNow(1f, currentParallax())
            if (locked) {
                hiddenWhileLockedOrOff = true
            } else if (settings.visibilityFallback && hiddenWhileLockedOrOff && interactive &&
                now - lastTriggerAt >= DEBOUNCE_MS
            ) {
                // Fallback for ROMs where USER_PRESENT is late/missing: visible again, keyguard gone.
                lastTriggerAt = now
                hiddenWhileLockedOrOff = false
                startUnlock("visibility-fallback")
            }
        }

        private fun onUnlockSignal(source: String) {
            val now = SystemClock.elapsedRealtime()
            Dbg.d { "unlock signal=$source state=$state visible=$engineVisible surface=$surfaceReady progress=$progress sinceLast=${now - lastTriggerAt}ms" }
            if (!settings.enabled) return
            if (runner.running && transitionTarget >= 1f) return // an unlock is already animating
            if (now - lastTriggerAt < DEBOUNCE_MS) return        // duplicate signal
            lastTriggerAt = now
            hiddenWhileLockedOrOff = false
            parallaxAmt = 0f // lock pose must not retain a displaced HOME frame

            if (engineVisible && surfaceReady) {
                pendingUntil = 0L
                if (holdPose() && progress >= HOME_EPS && !runner.running) {
                    // The lock pose was never shown, so animating from it would start with a visible jump.
                    Dbg.d { "unlock motion skipped: the HOME pose is already on screen" }
                    return
                }
                startUnlock(source)
            } else {
                // Bounded pending transition: honoured only if we become visible shortly.
                pendingUntil = now + PENDING_TTL_MS
            }
        }

        private fun onScreenOff() {
            // MIUI delivers SCREEN_OFF/ON ~0.2-0.7 s late. If the screen is on again by now, this one is stale
            // and must not cut a running wake-up animation short.
            if (power?.isInteractive == true) {
                Dbg.d { "stale SCREEN_OFF ignored (screen is on)" }
                return
            }
            interactive = false
            hiddenWhileLockedOrOff = true
            parallaxAmt = 0f // lock pose must not retain a displaced HOME frame
            resetToRest("screen-off")
            // A settings change invalidates the decoded / blurred bitmaps. Rebuild them now, while the screen
            // is off, instead of at the moment the next wake animation starts.
            if (!configured && surfaceReady) ensureConfigured()
        }

        private fun onScreenOn() {
            interactive = true
            pendingUntil = 0L // a wake-up is not an unlock
            Dbg.d { "screen on (no unlock motion)" }
        }

        /** RESET: drop transient state and settle on the pose the running transition was heading to. */
        private fun resetToRest(reason: String) {
            Dbg.d { "reset reason=$reason state=$state" }
            val wasAnimating = runner.running
            state = EngineState.RESET
            cancelRun(reason)
            pendingUntil = 0L
            if (wasAnimating && engineVisible && surfaceReady) {
                drawNow(transitionTarget, if (transitionTarget >= 1f) currentParallax() else 0f)
            } else if (parallaxAmt != 0f && engineVisible && surfaceReady) {
                drawNow(1f, currentParallax())
            }
            state = if (engineVisible) EngineState.STATIC else EngineState.INVISIBLE
        }

        private fun applySettings() {
            settings = SettingsStore.load(ctx)
            configured = false
            if (!settings.enabled) pendingUntil = 0L
            cancelRun("settings changed")
            state = if (engineVisible) EngineState.STATIC else EngineState.INVISIBLE
            // Hidden engines are reconfigured lazily the next time they become visible.
            if (engineVisible && surfaceReady) {
                ensureConfigured()
                if (holdPose() && progress < HOME_EPS) drawNow(0f, 0f) else drawNow(1f, currentParallax())
            }
        }

        // ---------------------------------------------------------------- transitions

        private fun startUnlock(source: String) {
            // Continue from the pose on screen (LOCK pose) so there is no jump; if HOME is on screen, start from LOCK.
            val from = if (progress < HOME_EPS) progress else 0f
            startTransition(from, 1f, source)
        }

        private fun startTransition(from: Float, to: Float, source: String) {
            if (!settings.enabled || !engineVisible || !surfaceReady) return
            if (runner.running) {
                if (transitionTarget == to) return // never stack the same transition
                cancelRun("replaced by $source")
            }
            if (settings.reducedMotion || !ValueAnimator.areAnimatorsEnabled()) {
                Dbg.d { "reduced motion (app setting or system animations off): jumping to the end look" }
                drawNow(to, if (to >= 1f) currentParallax() else 0f)
                return
            }
            if (!ensureConfigured()) return

            val duration = (settings.durationMs * animationScale()).toLong().coerceIn(120L, 1500L)
            Dbg.d {
                "transition start source=$source ${from}->${to} duration=${duration}ms easing=${settings.easing} " +
                    "style=${Presets.label(settings)} lock=${settings.lock} home=${settings.home}"
            }
            frames = 0
            maxGapMs = 0L
            lastFrameNs = 0L
            maxDrawMs = 0L
            firstFrameDelayMs = -1L
            requestedNs = System.nanoTime()
            transitionTarget = to
            state = EngineState.UNLOCK_TRANSITION
            runner.start(duration, settings.easing, from, to)
            if (BuildConfig.DEBUG) {
                watchdogDueAt = SystemClock.uptimeMillis() + WATCHDOG_MS
                handler.postDelayed(watchdog, WATCHDOG_MS)
            }
        }

        /** Stops a running transition (if any), logs why, and removes the debug watchdog. */
        private fun cancelRun(reason: String) {
            handler.removeCallbacks(watchdog)
            if (runner.running) {
                Dbg.d { "transition cancelled ($reason) frames=$frames firstFrameDelay=${firstFrameDelayMs}ms fallbackDriver=${runner.usedFallback}" }
                runner.cancel()
                progress = transitionTarget // logical pose; the next visible frame redraws it
            }
        }

        override fun onTransitionFrame(value: Float) {
            if (frames == 0) {
                firstFrameDelayMs = (System.nanoTime() - requestedNs) / 1_000_000L
                if (firstFrameDelayMs > STALE_START_MS) {
                    // The system was too late to give us a frame: the moment has passed, so playing the
                    // motion now would look like a random glitch. Settle on the end pose instead.
                    Dbg.d { "STALE: first frame came ${firstFrameDelayMs}ms after the trigger; motion skipped" }
                    cancelRun("stale start")
                    drawNow(transitionTarget, if (transitionTarget >= 1f) currentParallax() else 0f)
                    state = if (engineVisible) EngineState.STATIC else EngineState.INVISIBLE
                    return
                }
            }
            progress = value
            parallaxAmt = 0f
            drawFrame(value, 0f)
            if (BuildConfig.DEBUG) {
                val now = System.nanoTime()
                if (lastFrameNs != 0L) {
                    val gap = (now - lastFrameNs) / 1_000_000L
                    if (gap > maxGapMs) maxGapMs = gap
                }
                lastFrameNs = now
            }
            frames++
        }

        override fun onTransitionFinished() {
            handler.removeCallbacks(watchdog)
            drawNow(transitionTarget, if (transitionTarget >= 1f) currentParallax() else 0f)
            state = if (engineVisible) EngineState.STATIC else EngineState.INVISIBLE
            Dbg.d {
                "transition finished frames=$frames firstFrameDelay=${firstFrameDelayMs}ms maxFrameGap=${maxGapMs}ms " +
                    "maxDraw=${maxDrawMs}ms fallbackDriver=${runner.usedFallback} (no frames are scheduled now)"
            }
        }

        /** Honour the system "Animator duration scale" (0 is handled by areAnimatorsEnabled()). */
        private fun animationScale(): Float = try {
            Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
                .coerceIn(0.5f, 1.5f)
        } catch (e: Exception) {
            1f
        }

        // ---------------------------------------------------------------- drawing

        private fun drawNow(p: Float, f: Float) {
            progress = p
            parallaxAmt = if (p >= HOME_EPS) f else 0f
            drawFrame(p, parallaxAmt)
        }

        private fun ensureConfigured(): Boolean {
            val density = ctx.resources.displayMetrics.density
            configured = renderer.configure(surfW, surfH, settings, density)
            return configured
        }

        private fun drawFrame(p: Float, f: Float) {
            val holder = surfaceHolder ?: return
            if (!holder.surface.isValid) return
            var canvas: Canvas? = null
            val drawStart = System.nanoTime()
            try {
                canvas = if (useHardwareCanvas) holder.lockHardwareCanvas() else holder.lockCanvas()
                if (canvas != null) renderer.draw(canvas, p, f)
            } catch (e: Exception) {
                Dbg.d { "draw failed (hardware=$useHardwareCanvas): $e" }
                useHardwareCanvas = false
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        // surface went away while drawing; the next surface callback redraws
                    }
                }
            }
            if (BuildConfig.DEBUG) {
                val ms = (System.nanoTime() - drawStart) / 1_000_000L
                if (ms > maxDrawMs) maxDrawMs = ms
                if (ms > 100L) Dbg.d { "slow draw: ${ms}ms (hardwareCanvas=$useHardwareCanvas)" }
            }
        }
    }
}
