package com.subtleunlock.wallpaper

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/**
 * Tiny diagnostics helper. Compiles to nothing in release builds.
 * Debug builds write to logcat (adb logcat -s SubtleUnlock) and to the in-app event log.
 */
object Dbg {
    const val TAG = "SubtleUnlock"

    inline fun d(msg: () -> String) {
        if (BuildConfig.DEBUG) {
            val m = msg()
            Log.d(TAG, m)
            EventLog.add(m)
        }
    }
}

/**
 * Direction of the slide part of the motion. The LOCK look is offset in the direction (ux, uy) and the
 * picture glides back to (0, 0) on unlock, so UP means "the picture moves up while settling".
 */
enum class Direction(val key: String, val label: String, val ux: Float, val uy: Float) {
    UP("up", "Up", 0f, 1f),
    DOWN("down", "Down", 0f, -1f),
    LEFT("left", "Left", 1f, 0f),
    RIGHT("right", "Right", -1f, 0f),
    UP_LEFT("up_left", "Up-left", 0.7071f, 0.7071f),
    UP_RIGHT("up_right", "Up-right", -0.7071f, 0.7071f),
    DOWN_LEFT("down_left", "Down-left", 0.7071f, -0.7071f),
    DOWN_RIGHT("down_right", "Down-right", -0.7071f, -0.7071f);

    companion object {
        fun fromKey(key: String?): Direction = values().firstOrNull { it.key == key } ?: UP
    }
}

/** Shape of the motion over time. Springy overshoots by about 13% and settles. */
enum class Easing(val key: String, val label: String) {
    SMOOTH("smooth", "Smooth (ease-out)"),
    SOFT("soft", "Soft (ease-in-out)"),
    SPRING("spring", "Springy");

    companion object {
        fun fromKey(key: String?): Easing = values().firstOrNull { it.key == key } ?: SOFT
    }
}

/**
 * How the wallpaper looks in one state (lock screen or home screen). All values are "how far from
 * the untouched picture"; zero everywhere is the plain picture.
 */
data class Look(
    /** Signed. Negative = zoomed OUT, positive = zoomed IN. */
    val zoomPercent: Int = 0,
    val slideDp: Int = 0,
    val tiltTenths: Int = 0,
    /** Darkening overlay: 0 = none. */
    val dimPercent: Int = 0,
    /** Opacity of the optional second wallpaper image layered over this look. */
    val fadePercent: Int = 0,
    /** 0 = colour, 100 = fully grayscale. */
    val grayPercent: Int = 0,
    /** 0 = sharp, 100 = strongly blurred. */
    val blurPercent: Int = 0,
    /** Frame: the picture is inset from the screen edges by this much, with rounded corners. */
    val insetDp: Int = 0
) {
    companion object {
        val NONE = Look()
    }
}

/**
 * All motion options.
 *
 * The wallpaper has independent LOCK, HOME and APP-DRAWER looks. Lock/unlock transitions blend
 * LOCK and HOME; the launcher's zoom callback blends HOME and APP-DRAWER. Horizontal desktop-page
 * parallax is driven separately by onOffsetsChanged and never replaces the app-drawer signal.
 */
data class MotionSettings(
    val enabled: Boolean,
    /** Pause live wallpaper motion while retaining the currently rendered frame. */
    val offlineMode: Boolean,
    val holdLockPose: Boolean,
    val lockAnimate: Boolean,
    val reducedMotion: Boolean,
    val durationMs: Int,
    val easing: Easing,
    val direction: Direction,
    val lock: Look,
    val home: Look,
    /** Independent app-drawer/app-opening appearance, driven by launcher zoom callbacks. */
    val drawer: Look,
    /** Corner radius of the frame (only visible when a look has a frame inset). */
    val frameCornerDp: Int,
    val followLauncher: Boolean,
    /** Signed. Negative: wallpaper zooms OUT as the launcher goes deeper (drawer, app open). */
    val followZoomPercent: Int,
    val followSlideDp: Int,
    /** Horizontal home-screen page parallax; independent from the app-drawer depth callback. */
    val desktopParallaxEnabled: Boolean,
    val desktopParallaxStrengthDp: Int,
    val visibilityFallback: Boolean,
    /** Id of the last style the user picked ("custom" or "" if none). Display only. */
    val styleId: String,
    val wallpaperId: String,
    val secondWallpaperId: String,
    val appThemeMode: String,
    val appBackgroundMode: String,
    val backgroundBlurDp: Int,
    val backgroundDimPercent: Int,
    val accentColor: String
) {
    companion object {
        const val MIN_DURATION_MS = 150
        const val MAX_DURATION_MS = 1200
        const val MAX_ZOOM_PERCENT = 10 // used as +/-
        const val MAX_SLIDE_DP = 48
        const val MAX_TILT_TENTHS = 30
        const val MAX_DIM_PERCENT = 60
        const val MAX_INSET_DP = 24
        const val MAX_CORNER_DP = 40

        // Defaults = the "Classic Frame Zoom" style = the v1.3 look
        const val DEFAULT_ENABLED = true
        const val DEFAULT_HOLD_LOCK_POSE = true
        const val DEFAULT_LOCK_ANIMATE = true
        const val DEFAULT_REDUCED_MOTION = false
        const val DEFAULT_DURATION_MS = 450
        val DEFAULT_EASING = Easing.SOFT
        val DEFAULT_DIRECTION = Direction.UP
        val DEFAULT_LOCK = Look(zoomPercent = -5)
        val DEFAULT_HOME = Look.NONE
        const val DEFAULT_FRAME_CORNER_DP = 28
        const val DEFAULT_FOLLOW = true
        const val DEFAULT_FOLLOW_ZOOM_PERCENT = -5
        const val DEFAULT_FOLLOW_SLIDE_DP = 0
        const val DEFAULT_DESKTOP_PARALLAX = true
        const val DEFAULT_DESKTOP_PARALLAX_STRENGTH_DP = 10
        const val MAX_DESKTOP_PARALLAX_STRENGTH_DP = 24
        const val DEFAULT_VISIBILITY_FALLBACK = false
    }
}

/** One-tap bundles of the motion options. They never change the chosen wallpaper image. */
object Presets {
    class Preset(
        val id: String,
        val name: String,
        val description: String,
        val transform: (MotionSettings) -> MotionSettings
    )

    /** The shared starting point: every preset sets every field it controls, so that "matches" is exact. */
    private fun base(s: MotionSettings, durationMs: Int, lock: Look, home: Look): MotionSettings = s.copy(
        holdLockPose = true,
        lockAnimate = true,
        durationMs = durationMs,
        easing = Easing.SOFT,
        direction = Direction.UP,
        lock = lock,
        home = home,
        frameCornerDp = MotionSettings.DEFAULT_FRAME_CORNER_DP,
        followLauncher = true,
        followZoomPercent = MotionSettings.DEFAULT_FOLLOW_ZOOM_PERCENT,
        followSlideDp = MotionSettings.DEFAULT_FOLLOW_SLIDE_DP,
        drawer = Look(zoomPercent = MotionSettings.DEFAULT_FOLLOW_ZOOM_PERCENT)
    )

    /** Styles shown on the main screen. */
    val main: List<Preset> = listOf(
        Preset("classic", "Classic Frame Zoom", "Zoomed out on the lock screen, zooms in on unlock. The default.") {
            base(it, 450, Look(zoomPercent = -5), Look.NONE)
        },
        Preset("gray_lock", "Grayscale Lock Screen", "Black and white while locked, colour returns on the home screen.") {
            base(it, 600, Look(grayPercent = 100), Look.NONE)
        },
        Preset("gray_home", "Grayscale Home Screen", "Colour on the lock screen, black and white on the home screen.") {
            base(it, 600, Look.NONE, Look(grayPercent = 100))
        },
        Preset("blur_reveal", "Blur Reveal", "Blurred while locked, gradually sharpens on unlock.") {
            base(it, 700, Look(blurPercent = 70), Look.NONE)
        },
        Preset("blur_home", "Blurred Home Screen", "Sharp lock screen, softly blurred home screen.") {
            base(it, 700, Look.NONE, Look(blurPercent = 60))
        },
        Preset("zoom_gray", "Zoom + Grayscale", "Framed zoom and black and white on the lock screen.") {
            base(it, 600, Look(zoomPercent = -5, grayPercent = 100), Look.NONE)
        },
        Preset("zoom_blur", "Zoom + Blur", "Framed zoom and blur that clear together on unlock.") {
            base(it, 700, Look(zoomPercent = -5, blurPercent = 60), Look.NONE)
        },
        Preset("gray_blur", "Grayscale + Blur", "Blurred black and white lock screen, sharp colour home screen.") {
            base(it, 700, Look(grayPercent = 100, blurPercent = 60), Look.NONE)
        },
        Preset("fade_reveal", "Fade Reveal", "A restrained fade up from dark with a touch of zoom.") {
            base(it, 700, Look(zoomPercent = -3, dimPercent = 35), Look.NONE)
        },
        Preset("pixel_ambient", "Pixel Ambient", "A quiet inset frame with rounded corners that opens to full screen.") {
            base(it, 500, Look(dimPercent = 12, insetDp = 10), Look.NONE).copy(
                followZoomPercent = -3,
                drawer = Look(zoomPercent = -3)
            )
        }
    )

    /** Earlier styles, kept so nothing that worked is lost. Shown under Advanced. */
    val legacy: List<Preset> = listOf(
        Preset("cinematic", "Cinematic", "Bigger zoom, slide and dim.") {
            base(it, 800, Look(zoomPercent = -7, slideDp = 16, dimPercent = 20), Look.NONE).copy(
                followZoomPercent = -7,
                drawer = Look(zoomPercent = -7)
            )
        },
        Preset("light_up", "Light up", "Dark lock screen that brightens on unlock.") {
            base(it, 600, Look(dimPercent = 45), Look.NONE).copy(
                followLauncher = false, followZoomPercent = 0, drawer = Look.NONE
            )
        },
        Preset("playful", "Playful", "Springy diagonal slide with a little tilt.") {
            base(it, 700, Look(zoomPercent = -3, slideDp = 26, tiltTenths = 10), Look.NONE).copy(
                easing = Easing.SPRING, direction = Direction.UP_RIGHT,
                followZoomPercent = -3, followSlideDp = 10,
                drawer = Look(zoomPercent = -3, slideDp = 10)
            )
        },
        Preset("slide_classic", "Slide (classic)", "The first version: jump away, slide back.") {
            base(it, 320, Look(slideDp = 12), Look.NONE).copy(
                holdLockPose = false, lockAnimate = false, easing = Easing.SMOOTH,
                followZoomPercent = 0, followSlideDp = 12,
                drawer = Look(slideDp = 12)
            )
        }
    )

    val all: List<Preset> = main + legacy

    fun byId(id: String): Preset? = all.firstOrNull { it.id == id }

    /** The preset whose values equal [s] exactly, if any. */
    fun matching(s: MotionSettings): Preset? = all.firstOrNull { it.transform(s) == s }

    /** Human-readable description of the current configuration, e.g. "Custom (modified from Blur Reveal)". */
    fun label(s: MotionSettings): String {
        val chosen = byId(s.styleId)
        return when {
            chosen != null && chosen.transform(s) == s -> chosen.name
            chosen != null -> "Custom (modified from " + chosen.name + ")"
            else -> matching(s)?.name ?: "Custom"
        }
    }
}

object SettingsStore {
    private const val PREFS = "motion_settings"
    private const val KEY_VERSION = "settings_version"
    private const val CURRENT_VERSION = 2

    const val KEY_ENABLED = "enabled"
    const val KEY_OFFLINE_MODE = "offline_mode"
    const val KEY_HOLD = "hold_lock_pose"
    const val KEY_LOCK_ANIM = "lock_animate"
    const val KEY_REDUCED = "reduced_motion"
    const val KEY_DURATION = "duration_ms"
    const val KEY_EASING = "easing"
    const val KEY_DIRECTION = "direction"
    const val KEY_FRAME_CORNER = "frame_corner_dp"
    const val KEY_FOLLOW = "follow_launcher"
    const val KEY_FOLLOW_ZOOM = "follow_zoom_percent"
    const val KEY_FOLLOW_SLIDE = "follow_slide_dp"
    const val KEY_DESKTOP_PARALLAX = "desktop_parallax_enabled"
    const val KEY_DESKTOP_PARALLAX_STRENGTH = "desktop_parallax_strength_dp"
    const val KEY_FALLBACK = "visibility_fallback"
    const val KEY_STYLE = "style_id"
    const val KEY_WALLPAPER = "wallpaper_id"
    const val KEY_SECOND_WALLPAPER = "second_wallpaper_id"
    const val KEY_APP_THEME = "app_theme_mode"
    const val KEY_APP_BACKGROUND = "app_background_mode"
    const val KEY_BG_BLUR = "background_blur_dp"
    const val KEY_BG_DIM = "background_dim_percent"
    const val KEY_ACCENT = "accent_color"

    // LOCK look keeps the v1.3 key names, so existing installs keep their look.
    private const val L_ZOOM = "zoom_percent"
    private const val L_SLIDE = "distance_dp"
    private const val L_TILT = "rotation_tenths"
    private const val L_DIM = "dim_percent"
    private const val L_FADE = "lock_fade"
    private const val L_GRAY = "lock_gray"
    private const val L_BLUR = "lock_blur"
    private const val L_INSET = "lock_inset"
    private const val H_ZOOM = "home_zoom"
    private const val H_SLIDE = "home_slide"
    private const val H_TILT = "home_tilt"
    private const val H_DIM = "home_dim"
    private const val H_FADE = "home_fade"
    private const val H_GRAY = "home_gray"
    private const val H_BLUR = "home_blur"
    private const val H_INSET = "home_inset"
    private const val D_ZOOM = "drawer_zoom"
    private const val D_SLIDE = "drawer_slide"
    private const val D_TILT = "drawer_tilt"
    private const val D_DIM = "drawer_dim"
    private const val D_FADE = "drawer_fade"
    private const val D_GRAY = "drawer_gray"
    private const val D_BLUR = "drawer_blur"
    private const val D_INSET = "drawer_inset"

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** v1.0-1.2 stored a different motion model; drop those values once so the new defaults apply. */
    private fun migrate(p: SharedPreferences) {
        if (p.getInt(KEY_VERSION, 1) >= CURRENT_VERSION) return
        p.edit()
            .remove(L_SLIDE).remove(KEY_DURATION).remove(KEY_DIRECTION)
            .remove(KEY_FOLLOW).remove("zoom").remove(L_ZOOM)
            .putInt(KEY_VERSION, CURRENT_VERSION)
            .apply()
    }

    private fun readLook(
        p: SharedPreferences, zoom: String, slide: String, tilt: String, dim: String,
        gray: String, blur: String, inset: String, fade: String, def: Look
    ): Look = Look(
        zoomPercent = p.getInt(zoom, def.zoomPercent).coerceIn(-MotionSettings.MAX_ZOOM_PERCENT, MotionSettings.MAX_ZOOM_PERCENT),
        slideDp = p.getInt(slide, def.slideDp).coerceIn(0, MotionSettings.MAX_SLIDE_DP),
        tiltTenths = p.getInt(tilt, def.tiltTenths).coerceIn(0, MotionSettings.MAX_TILT_TENTHS),
        dimPercent = p.getInt(dim, def.dimPercent).coerceIn(0, MotionSettings.MAX_DIM_PERCENT),
        fadePercent = p.getInt(fade, def.fadePercent).coerceIn(0, 100),
        grayPercent = p.getInt(gray, def.grayPercent).coerceIn(0, 100),
        blurPercent = p.getInt(blur, def.blurPercent).coerceIn(0, 100),
        insetDp = p.getInt(inset, def.insetDp).coerceIn(0, MotionSettings.MAX_INSET_DP)
    )

    fun load(context: Context): MotionSettings {
        val p = prefs(context)
        migrate(p)
        // Older installs used only followZoom/followSlide. Seed the new drawer look from those
        // values so the update preserves the user's existing app-drawer motion.
        val drawerDefault = Look(
            zoomPercent = p.getInt(KEY_FOLLOW_ZOOM, MotionSettings.DEFAULT_FOLLOW_ZOOM_PERCENT),
            slideDp = p.getInt(KEY_FOLLOW_SLIDE, MotionSettings.DEFAULT_FOLLOW_SLIDE_DP)
        )
        return MotionSettings(
            enabled = p.getBoolean(KEY_ENABLED, MotionSettings.DEFAULT_ENABLED),
            offlineMode = p.getBoolean(KEY_OFFLINE_MODE, false),
            holdLockPose = p.getBoolean(KEY_HOLD, MotionSettings.DEFAULT_HOLD_LOCK_POSE),
            lockAnimate = p.getBoolean(KEY_LOCK_ANIM, MotionSettings.DEFAULT_LOCK_ANIMATE),
            reducedMotion = p.getBoolean(KEY_REDUCED, MotionSettings.DEFAULT_REDUCED_MOTION),
            durationMs = p.getInt(KEY_DURATION, MotionSettings.DEFAULT_DURATION_MS)
                .coerceIn(MotionSettings.MIN_DURATION_MS, MotionSettings.MAX_DURATION_MS),
            easing = Easing.fromKey(p.getString(KEY_EASING, MotionSettings.DEFAULT_EASING.key)),
            direction = Direction.fromKey(p.getString(KEY_DIRECTION, MotionSettings.DEFAULT_DIRECTION.key)),
            lock = readLook(p, L_ZOOM, L_SLIDE, L_TILT, L_DIM, L_GRAY, L_BLUR, L_INSET, L_FADE, MotionSettings.DEFAULT_LOCK),
            home = readLook(p, H_ZOOM, H_SLIDE, H_TILT, H_DIM, H_GRAY, H_BLUR, H_INSET, H_FADE, MotionSettings.DEFAULT_HOME),
            drawer = readLook(p, D_ZOOM, D_SLIDE, D_TILT, D_DIM, D_GRAY, D_BLUR, D_INSET, D_FADE, drawerDefault),
            frameCornerDp = p.getInt(KEY_FRAME_CORNER, MotionSettings.DEFAULT_FRAME_CORNER_DP)
                .coerceIn(0, MotionSettings.MAX_CORNER_DP),
            followLauncher = p.getBoolean(KEY_FOLLOW, MotionSettings.DEFAULT_FOLLOW),
            followZoomPercent = p.getInt(KEY_FOLLOW_ZOOM, MotionSettings.DEFAULT_FOLLOW_ZOOM_PERCENT)
                .coerceIn(-MotionSettings.MAX_ZOOM_PERCENT, MotionSettings.MAX_ZOOM_PERCENT),
            followSlideDp = p.getInt(KEY_FOLLOW_SLIDE, MotionSettings.DEFAULT_FOLLOW_SLIDE_DP)
                .coerceIn(0, MotionSettings.MAX_SLIDE_DP),
            desktopParallaxEnabled = p.getBoolean(KEY_DESKTOP_PARALLAX, MotionSettings.DEFAULT_DESKTOP_PARALLAX),
            desktopParallaxStrengthDp = p.getInt(KEY_DESKTOP_PARALLAX_STRENGTH, MotionSettings.DEFAULT_DESKTOP_PARALLAX_STRENGTH_DP)
                .coerceIn(0, MotionSettings.MAX_DESKTOP_PARALLAX_STRENGTH_DP),
            visibilityFallback = p.getBoolean(KEY_FALLBACK, MotionSettings.DEFAULT_VISIBILITY_FALLBACK),
            styleId = p.getString(KEY_STYLE, "") ?: "",
            wallpaperId = p.getString(KEY_WALLPAPER, Wallpapers.DEFAULT_ID) ?: Wallpapers.DEFAULT_ID,
            secondWallpaperId = p.getString(KEY_SECOND_WALLPAPER, "") ?: "",
            appThemeMode = p.getString(KEY_APP_THEME, "system") ?: "system",
            appBackgroundMode = p.getString(KEY_APP_BACKGROUND, "wallpaper") ?: "wallpaper",
            backgroundBlurDp = p.getInt(KEY_BG_BLUR, 36).coerceIn(0, 80),
            backgroundDimPercent = p.getInt(KEY_BG_DIM, 38).coerceIn(0, 80),
            accentColor = p.getString(KEY_ACCENT, "system") ?: "system"
        )
    }

    /** Writes every field. SharedPreferences only notifies listeners for values that actually changed. */
    fun save(context: Context, s: MotionSettings) {
        prefs(context).edit()
            .putInt(KEY_VERSION, CURRENT_VERSION)
            .putBoolean(KEY_ENABLED, s.enabled)
            .putBoolean(KEY_OFFLINE_MODE, s.offlineMode)
            .putBoolean(KEY_HOLD, s.holdLockPose)
            .putBoolean(KEY_LOCK_ANIM, s.lockAnimate)
            .putBoolean(KEY_REDUCED, s.reducedMotion)
            .putInt(KEY_DURATION, s.durationMs)
            .putString(KEY_EASING, s.easing.key)
            .putString(KEY_DIRECTION, s.direction.key)
            .putInt(L_ZOOM, s.lock.zoomPercent)
            .putInt(L_SLIDE, s.lock.slideDp)
            .putInt(L_TILT, s.lock.tiltTenths)
            .putInt(L_DIM, s.lock.dimPercent)
            .putInt(L_FADE, s.lock.fadePercent)
            .putInt(L_GRAY, s.lock.grayPercent)
            .putInt(L_BLUR, s.lock.blurPercent)
            .putInt(L_INSET, s.lock.insetDp)
            .putInt(H_ZOOM, s.home.zoomPercent)
            .putInt(H_SLIDE, s.home.slideDp)
            .putInt(H_TILT, s.home.tiltTenths)
            .putInt(H_DIM, s.home.dimPercent)
            .putInt(H_FADE, s.home.fadePercent)
            .putInt(H_GRAY, s.home.grayPercent)
            .putInt(H_BLUR, s.home.blurPercent)
            .putInt(H_INSET, s.home.insetDp)
            .putInt(D_ZOOM, s.drawer.zoomPercent)
            .putInt(D_SLIDE, s.drawer.slideDp)
            .putInt(D_TILT, s.drawer.tiltTenths)
            .putInt(D_DIM, s.drawer.dimPercent)
            .putInt(D_FADE, s.drawer.fadePercent)
            .putInt(D_GRAY, s.drawer.grayPercent)
            .putInt(D_BLUR, s.drawer.blurPercent)
            .putInt(D_INSET, s.drawer.insetDp)
            .putInt(KEY_FRAME_CORNER, s.frameCornerDp)
            .putBoolean(KEY_FOLLOW, s.followLauncher)
            .putInt(KEY_FOLLOW_ZOOM, s.followZoomPercent)
            .putInt(KEY_FOLLOW_SLIDE, s.followSlideDp)
            .putBoolean(KEY_DESKTOP_PARALLAX, s.desktopParallaxEnabled)
            .putInt(KEY_DESKTOP_PARALLAX_STRENGTH, s.desktopParallaxStrengthDp)
            .putBoolean(KEY_FALLBACK, s.visibilityFallback)
            .putString(KEY_STYLE, s.styleId)
            .putString(KEY_WALLPAPER, s.wallpaperId)
            .putString(KEY_SECOND_WALLPAPER, s.secondWallpaperId)
            .putString(KEY_APP_THEME, s.appThemeMode)
            .putString(KEY_APP_BACKGROUND, s.appBackgroundMode)
            .putInt(KEY_BG_BLUR, s.backgroundBlurDp)
            .putInt(KEY_BG_DIM, s.backgroundDimPercent)
            .putString(KEY_ACCENT, s.accentColor)
            .apply()
    }

    /** Resets motion options to the "Classic Frame Zoom" style; the chosen wallpaper image is kept. */
    fun resetMotionToDefaults(context: Context) {
        val current = load(context)
        val reset = Presets.main[0].transform(
            current.copy(
                enabled = MotionSettings.DEFAULT_ENABLED,
                offlineMode = false,
                reducedMotion = MotionSettings.DEFAULT_REDUCED_MOTION,
                visibilityFallback = MotionSettings.DEFAULT_VISIBILITY_FALLBACK
            )
        )
        save(context, reset.copy(styleId = Presets.main[0].id))
    }
}
