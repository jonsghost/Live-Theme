# Subtle Unlock Motion

A native Kotlin live wallpaper with restrained lock/unlock transitions and horizontal home-screen desktop parallax. It uses static photos only. No gyroscope, accelerometer, foreground service, network access or app permissions.

## 1. Honest status (read this first)

| Item | Status |
|---|---|
| Source project, resources, 3 bundled wallpapers, settings UI, README | **Updated to v1.5 source** |
| Horizontal desktop parallax | **Implemented using launcher `onOffsetsChanged` callbacks**; event-driven, no timer or sensor |
| ZipDepth AI depth inference | **Not yet integrated.** This build uses a subtle whole-image horizontal shift; depth-aware foreground/background separation requires an exported mobile model and inference adapter. |
| `app-debug.apk` | **Not built in this environment.** No Android SDK or Gradle installation is available here. |
| Android compile/device test | **Pending GitHub Actions and physical-device verification.** Static project checks pass; see below. |
| Works on your phone / MIUI unlock timing | **Partly measured (v1.0 log, POCO M2 Pro, Android 12).** Compiles and runs; `USER_PRESENT` fires on unlock; drawing is smooth (20 frames, max gap 27 ms). But the first frame arrived ~5 s after unlock, so the effect did not play at unlock. See section 2a. |

What *was* checked here (build-time only, no device):

* `python3 tools/static_checks.py`: bracket balance of all Kotlin files, XML well-formedness, every `R.*`/manifest/asset reference resolves, manifest declares **zero** permissions. **PASS**
* `python3 tools/verify_geometry.py`: a Python port of the renderer maths, run over 840 combinations (3 screen sizes x 7 image shapes x 4 directions x zoom on/off x 5 distances, 1001 animation steps each). Result: the image **never exposes an edge**, the easing never overshoots, and on your 1080x2400 screen the resting frame is drawn at scale 1.00000 with integer pixel offsets. This is a simulation of the maths, not a render test.
* The three wallpapers were generated and visually inspected (`tools/generate_wallpapers.py`).

## 2. What this app can and cannot do on MIUI

**It cannot change MIUI's native unlock animation.** The lock screen and its exit animation belong to System UI, which a normal app cannot hook without root or modifying MIUI. This app does the closest reliable thing: it detects the unlock and draws its own short wallpaper movement around the same moment.

Findings from research (API docs and Xiaomi's own pages) and what they mean here:

| Question | Finding | Consequence |
|---|---|---|
| Does `onVisibilityChanged(true)` mean "just unlocked"? | No. It also fires on screen-on (keyguard still showing), when apps close, and in previews. | Visibility alone is **never** treated as unlock by default. |
| Best unlock signal | `ACTION_USER_PRESENT` (public, sent when the keyguard is dismissed). Needs dynamic registration on modern Android, which the engine does for its lifetime (the system keeps the wallpaper process alive; no foreground service). | Primary trigger. |
| Order of events | Visibility and `USER_PRESENT` can arrive in either order. | If the signal arrives while hidden it is remembered for 1.5 s ("bounded pending transition") and played when the wallpaper becomes visible. Duplicates within 1.2 s are ignored; animations never stack. |
| Wallpaper zoom callbacks | `Engine.onZoomChanged` exists from API 30 (checked in the Android API diff). The zoom is driven by the launcher/System UI, is not documented as an unlock signal, and MIUI may or may not drive it. | Ignored in v1.5; no app-drawer or app-open motion is driven by this callback. |
| Which screen does an engine render? | `Engine.getWallpaperFlags()` is API 34, so it is unavailable on Android 12. | Per-engine state machine instead; two engines (home + lock) each decide for themselves. |
| Live wallpaper on the **lock screen** of Xiaomi/POCO | Mixed. Xiaomi's FAQ says third-party live wallpapers on the lock screen depend on the app supporting it and on permissions such as background running; community reports show some POCO/MIUI builds not showing third-party live wallpapers on the lock screen at all, with workarounds through the Themes app. MIUI's own "Super Wallpapers" have system-integrated lock-to-home transitions that third parties cannot reproduce. | Both setups work: **Both** (static on lock, moves at unlock), or **Home only** (home wallpaper is hidden under the keyguard, becomes visible after unlock, and moves then). If MIUI refuses to put the live wallpaper on the lock screen, set the **same picture** as a static lock-screen wallpaper in MIUI for visual continuity. |

Sources used: Android developer API diff (`WallpaperService.Engine`, `onZoomChanged` added at API 30; `getWallpaperFlags` listed as API 34), Xiaomi support FAQ KA-528017 (third-party live wallpaper on lock screen), Xiaomi support article KA-06655 (Super Wallpapers), plus forum reports (anecdotal).

**Expected visual behaviour.** `USER_PRESENT` is sent when the keyguard is dismissed, so the movement starts at about the time the system's own unlock transition runs, not frame-locked to it. The animation starts at the offset position (that is what "from the start offset to rest" means), so you may see a small first-frame shift that the keyguard fade mostly hides; a smaller distance makes it less noticeable.

## 2a. First on-device log (v1.0) and what v1.1 changes

Measured on the target phone (Android 12, `density=2.2`, surface 1080x2400):

* `USER_PRESENT` arrived on every unlock and a transition started. **Works.**
* `onZoomChanged` fired only for launcher app-open/close animations (zoom 0 to 0.6 and back), **never** around unlock. So zoom cannot be used as an unlock signal on this MIUI.
* `SCREEN_OFF`/`SCREEN_ON` broadcasts reached the app about 0.7 s late, i.e. MIUI delays delivery to this process.
* **Problem:** after `transition start` no frame was drawn for ~4.8 s (first run was cancelled still waiting; second run finished 5.1 s after it started, with 20 normal frames of max 27 ms once running). Either vsync was not delivered to the wallpaper process, or MIUI paused the process after unlock. v1.0 could not tell which.

Second log (still v1.0, after relaxing MIUI battery limits; no `app 1.1` line in its header):

* While a transition was "running" and drawing nothing, `onZoomChanged` callbacks kept arriving every ~16 ms and were processed on the main thread. So the **main thread was alive**; only the frame timer (Choreographer) delivered nothing to the wallpaper process (the in-app preview, which has a visible window, animates fine). That is exactly what the Handler fallback below is for.
* Launcher gestures (app drawer, app open/close, recents) produce a clean stream of zoom values (0 to about 0.6 for apps, 0 to 1.0 for another gesture) at ~60 per second. **No zoom events occur at lock or unlock.** The lock/unlock fade and zoom you see on MIUI are drawn by System UI and are not exposed to wallpapers.

Historical v1.1 / v1.2 changes:

* **v1.5 desktop-page parallax:** `onOffsetsChanged(xOffset)` drives a restrained horizontal shift only while the HOME pose is visible. App-drawer/app-open `onZoomChanged` is ignored. The renderer draws only when the launcher sends an offset callback; no animation loop, polling, gyroscope or accelerometer is used. The transition engine retains priority during lock/unlock motion.

* **Stale guard:** if the first frame arrives more than 600 ms after the unlock signal, the motion is skipped (no random glitch seconds later).
* **Handler fallback:** if Choreographer gives no frame within 48 ms, that transition is driven by a bounded 16 ms Handler loop instead.
* **Watchdog log (debug):** 700 ms after a transition starts with no frame, it logs whether the main thread was alive (check ran on time) or blocked/frozen (ran late).
* **More timing in the log:** `firstFrameDelay`, `maxDraw`, `fallbackDriver`, and why a transition was cancelled.
* **Settings:** a **Battery and autostart** button (opens the app info page) and MIUI build + app version in Diagnostics.

If MIUI is pausing the process, set the app's **Battery saver** to **No restrictions**, turn **Autostart** on, and (in Recents) lock the app card. Those are your choices to make; the app does not change them.

## 2b. v1.3: one cohesive motion model (fix for the "bouncing" unlock)

Log from v1.2 on the target phone (MIUI 14 build V14.0.5.0.SJPINXM): the Handler fallback works (`frames=28 firstFrameDelay=48ms maxFrameGap=19ms maxDraw=10ms`), and the unlock motion now plays. But the old model rested at the normal picture while locked, snapped the picture 24 dp away on the first frame, then slid it back. That snap reads as a bounce. MIUI also sends home-screen scroll offsets (`yOffset=0.5`, `xStep=0.333`).

v1.3 replaces it with two **poses**:

* **HOME** = the untouched picture. **LOCK** = the picture zoomed (default 5% out) and optionally slid, tilted, dimmed.
* The lock screen **rests in the LOCK pose**. Waking to the lock screen glides HOME to LOCK ("zoom out when locked"); unlocking glides LOCK to HOME ("clean zoom in"), starting from what is already on screen, so **there is no first-frame jump**.
* The previous app-drawer/app-open follow effect has been removed in v1.5. Horizontal home-screen page offsets now drive a restrained left/right wallpaper shift.
* Zooming OUT is possible because the decoded picture is a few percent larger than the screen (headroom), computed from the settings, so edges never show. The cost is that the edges of the picture are cropped slightly more.
* MIUI delivers SCREEN_OFF/ON 0.2 to 0.7 s late; a late SCREEN_OFF is ignored when the screen is already on, so it cannot cut the wake animation short.
* Settings from v1.0 to v1.2 are reset once to the new defaults (the chosen wallpaper image is kept).

Historical v1.3 controls (superseded by v1.4/v1.5): five one-tap styles, motion and lock-pose toggles, visibility fallback, per-look effects, duration/easing controls, and Unlock/Lock previews.

### v1.5 desktop parallax scope

* Only horizontal home-screen page movement is used. The app-drawer/app-open zoom callback is deliberately ignored.
* The current v1.5 renderer applies a subtle whole-image horizontal shift (default maximum travel: 18 dp from the centre of the launcher offset range). It is not yet per-pixel depth parallax.
* The accepted AI model candidate is **ZipDepth** (6.1M parameters, 384×384 input). Its mobile-oriented `zipdepth_base_npu` checkpoint is the appropriate export source; the official project documents ONNX export and mobile runtime conversion. The model checkpoint is not an ONNX runtime asset and is not bundled in this source archive.
* The next implementation stage is to export and validate a mobile ONNX model, integrate ONNX Runtime Android, run inference once when an image is selected/imported, cache a compact depth map, and use that map for GPU-driven depth displacement during horizontal page movement. No inference should run during swipe playback.
* **Static photos only.** GIF and video support remain excluded.

## 2c. v1.3 on-device review and v1.4 (animation styles + Material 3 settings)

Tested by the owner on a POCO M2 Pro, Android 12, MIUI V14.0.5.0.SJPINXM, **Lawnchair** launcher (the launcher's depth signal comes from Lawnchair, not MIUI Home): the v1.3 animation "looks significantly better" and is the **accepted baseline**. Log review (about 5 minutes of lock/unlock cycles) found **no defect that justifies changing it**:

* one transition per trigger; none overlapped or stacked; every one ended in the correct pose;
* no launcher-zoom callback arrived inside any transition window (they are ignored while one runs, by design);
* the stale `SCREEN_OFF` that MIUI delivers after the wake was caught every time;
* the ~48 ms first-frame delay is the designed Handler fallback (the Choreographer never delivers frames to the wallpaper process on this device); a single 88 ms draw appeared on the first frame after a wake (GPU re-upload of the picture) with no visible stutter reported. **Left untouched.**

**Rule kept in v1.4/v1.5:** when parallax is disabled and no other new effect is active, drawing takes the same single-bitmap path as v1.3. `tools/verify_geometry.py` checks baseline decode geometry against v1.3 for 1,200 random settings. With parallax enabled, additional overscan is decoded to prevent edge exposure.

### What v1.4 adds

* **Per-state looks.** The wallpaper has a **lock look** and a **home look**; each can set zoom (-10..+10 %), frame inset (0-24 dp), grayscale, blur, fade, and (advanced) slide and tilt. The transition glides between them, so any effect can run in either direction: grayscale lock to colour home, colour lock to grayscale home, blurred to sharp, sharp to blurred, framed to full screen, and combinations.
* **Styles:** Classic Frame Zoom (the v1.3 default, unchanged), Grayscale Lock Screen, Grayscale Home Screen, Blur Reveal, Blurred Home Screen, Zoom + Grayscale, Zoom + Blur, Grayscale + Blur, Fade Reveal, Pixel Ambient (inset rounded frame; no proprietary APIs), Custom. The four earlier styles (Cinematic, Light up, Playful, Slide classic) are kept under Advanced. Changing any slider after picking a style shows **"Custom (modified from X)"**; the active style tile is highlighted.
* **Transition controls:** duration, motion shape (smooth, soft, springy), rest-in-lock-look, wake animation, and a new **Reduced motion** switch (effects switch instantly). Android's own "Remove animations" is still honoured.
* **Material 3 settings screen** (plain platform widgets, no new library): dynamic colour on Android 12, light and dark themes, rounded cards, pill buttons, tonal tiles, an animated expandable Advanced section. **Every tappable element now has a ripple and a press animation** (previously the thumbnails and some buttons had none). Picking a style scrolls to the preview and plays it; Lock look / Home look / Unlock / Lock preview buttons.

### v1.5: horizontal desktop parallax

* Replaced app-drawer/app-open follow controls with **Home-screen desktop parallax** enable/strength settings.
* Reads the launcher's horizontal wallpaper offset (`xOffset`) through `onOffsetsChanged`; no gyro or accelerometer.
* Applies up to 18 dp of horizontal translation by default, with a 0–36 dp setting. Vertical movement and drawer/app-open zoom do not affect it.
* The lock/unlock transition state machine and its existing effects remain unchanged; parallax is suppressed during the LOCK pose and while a transition is running.
* Settings version 3 migrates the previous enable/disable choice, resets obsolete drawer tuning, and removes the retired preference keys.

### How the effects are rendered (lightweight, cached, bounded)

| Effect | Technique | Cost |
|---|---|---|
| Grayscale | colour-matrix filter on the Paint, updated in place (GPU) | no extra bitmap |
| Blur | two small pre-blurred copies (half and full strength) built when the picture, screen width or strongest blur changes; a frame cross-fades sharp, half, full | a few hundred KB; built once, on the main thread, a few tens of ms; rebuilt while the screen is off after a settings change |
| Frame | clip to an inset rounded rectangle (anti-aliased) over a dark fill | no extra bitmap |
| Fade | black overlay / alpha | none |
| Zoom, slide, tilt | matrix, as in v1.3 | none |

Nothing is decoded, blurred or allocated per frame; every cache is replaced when the image, size or relevant setting changes and dropped on `release()` / memory trim. There is no background thread, so there is nothing to cancel: the blur build is a bounded one-off, and if it ever causes a visible hitch it would be the first thing to move off the main thread. Blur at 100 % uses a 40 px (1080-wide) radius; the combined styles are the first to check for stutter (read `maxDraw` in Diagnostics).

### Tests and checks (what was and was not run)

* **Not run in the authoring environment** (no Android SDK or network there): Gradle build, the JVM unit tests, anything on a device.
* **Run here:** `tools/static_checks.py` (structure, resources, braces), `tools/verify_geometry.py` (v1.3 parity + no-edge coverage, 3,700 simulated cases), `tools/verify_blur.py` (box-blur index maths vs a naive blur).
* **Added for your build to run:** `app/src/test/.../PresetsTest.kt` (JUnit 4; style logic, preset distinctness, modified-label logic, blur maths). The updated `build-apk.yml` runs them after the APK is built and never blocks the APK.
* **Untested on a physical device:** every new effect (grayscale, blur, frame, fade styles), the new settings screen, and dynamic colour on MIUI. Test **individual effects first** (Grayscale Lock Screen, Blur Reveal, Pixel Ambient), then the combined styles, and watch `maxDraw` / `maxFrameGap` in Diagnostics.

### Limitations (unchanged)

The wallpaper service can only draw the wallpaper itself; it cannot draw above MIUI's lock-screen UI, and the system's own lock/unlock animation is not exposed. Lock/unlock timing comes from `ACTION_USER_PRESENT` and wallpaper visibility, which MIUI delivers with delay; the app compensates but cannot claim frame-perfect sync. If the wake-up or unlock signal is missing, the visibility fallback toggle is the documented backup.

## 3. How it works

```
STATIC ──unlock signal & visible──▶ UNLOCK_TRANSITION ──done──▶ STATIC
  │  ▲                                   │
  │  └───────── RESET (screen off, settings change, surface change) ◀┘
  ▼
INVISIBLE  (callbacks removed, nothing drawn; bitmap kept until memory trim)
```

* **Signals:** `USER_PRESENT` (trigger), `SCREEN_OFF` (reset to rest, clear pending), `SCREEN_ON` (clears pending; a wake-up is not an unlock), wallpaper visibility, surface callbacks. Optional **visibility fallback** (off by default): if the wallpaper becomes visible after being hidden while the screen was off/locked and the keyguard is gone, treat that as an unlock.
* **Rendering:** one decoded bitmap (decoded once by `ImageDecoder`, EXIF-aware, scaled to exactly "screen + motion margin"), one `Matrix`, one `Paint`. Translation and an optional 2% zoom-in that settles to 100%. No allocations in the frame path. Hardware canvas with automatic software fallback.
* **Timing:** `Choreographer` frame callbacks (monotonic `frameTimeNanos`), posted **only while the ~320 ms transition runs**, removed on finish, hide, surface loss or screen-off. A cubic ease-out with no overshoot, created once.
* **Respect for system settings:** if "Remove animations"/animator scale is 0 the motion is skipped; other scales scale the duration (clamped).
* **Memory:** one bitmap of about (screen + margin) x 4 bytes (about 12 MB on 1080x2400); released on engine destroy and on severe memory trim while hidden.
* **Edges:** the image is cropped to cover the screen plus a margin >= the travel distance on the moving axis only, so no edge is ever revealed (verified by simulation above).
* **Imported images** are copied byte-for-byte into `files/wallpapers/` (no re-encoding, no filters), validated, and the previous import is deleted.

Decisions worth knowing:

* `minSdk 28` because `ImageDecoder` (correct EXIF rotation, decode-time downscale) is API 28. `targetSdk 31` = your Android 12; it avoids behaviour changes from API 32-34 that are irrelevant here and matches what MIUI 12.5/13 on Android 12 expects. Sideloading is unaffected.
* Zero library dependencies; platform Material dark theme; UI built in code.
* Image decode runs on the engine's main thread when the wallpaper (re)loads (about 0.1 s for a large photo), never during the animation.

## 4. Inspect your phone (read-only commands)

```bash
adb devices
adb shell getprop ro.build.version.release        # Android version
adb shell getprop ro.build.version.sdk            # API level (31 = Android 12)
adb shell getprop ro.miui.ui.version.name         # MIUI version
adb shell getprop ro.build.version.incremental
adb shell getprop ro.product.cpu.abi
adb shell wm size
adb shell wm density
adb shell dumpsys display | grep -iE "fps|refreshRate|mode"
adb shell grep -E "MemTotal|MemAvailable" /proc/meminfo
```

## 5. Build

Requirements: Android Studio (Hedgehog or newer) or JDK 17 + Android SDK with **platform 34** and build-tools. First sync needs internet (Google/Maven repositories).

**Android Studio:** File > Open > the `SubtleUnlockWallpaper` folder > accept the SDK/Gradle prompts > Build > Build APK(s).

**Command line:**

```bash
# once, with any Gradle >= 8.2 installed (the wrapper JAR could not be bundled here)
gradle wrapper --gradle-version 8.2
echo "sdk.dir=$HOME/Android/Sdk" > local.properties   # path to your Android SDK
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk` (relative to the project folder; it exists only after you build).
A release-type build (debug-signed so it installs) is `./gradlew assembleRelease` -> `app/build/outputs/apk/release/app-release.apk`.

## 5a. No PC? Build the APK in the cloud, from your phone

GitHub builds it for you for free; you only need a browser and a free GitHub account.

1. In your phone browser open github.com, sign up/in, then **New repository** (name e.g. `unlock-motion`, Private is fine) and create it.
2. In the repo: **Add file > Upload files**, choose `SubtleUnlockWallpaper_v1.5_ClaudeBase.zip` and **Commit changes**. You do not need to extract it; the included workflow extracts the project automatically. If you cannot find "Add file", switch the browser to **Desktop site**.
3. The ZIP already contains `.github/workflows/build-apk.yml`. If the workflow file is not present in the repository after upload, create it at that path and paste the included workflow. Keep only this build workflow; remove any older `android.yml` workflow to avoid duplicate builds.
4. Open the **Actions** tab > the **Build Android APK** run. A green tick means success.
5. Open the finished run, scroll to **Artifacts**, tap **app-debug-apk** to download (a small zip containing `app-debug.apk`).
6. In your Files app, extract the zip, tap `app-debug.apk`, allow "install unknown apps" for that app if asked, and install. MIUI may show a safety scan screen; choose to continue.

If the run shows a **red cross**, open it, open the failed **Build debug APK** step and copy the lines that start with `e:` (compile errors) or "What went wrong", and send them to me. That is the first real compile of this code, so a small fix is plausible.

## 5b. Diagnostics without a PC

The debug build records recent events in memory. In the app tap **Diagnostics: recent unlock events**. Lock and unlock the phone a few times, reopen the app, open Diagnostics, and look for `unlock signal=USER_PRESENT` followed by `transition start` and `transition finished`. **Copy** puts the log on your clipboard so you can paste it to me. Nothing is written to disk or sent anywhere, and release builds record nothing.

## 6. Install and test (ADB, if you do have a computer)

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.subtleunlock.wallpaper/.SettingsActivity
adb shell dumpsys package com.subtleunlock.wallpaper | grep -iA3 "WallpaperService"   # service is registered
```

In the app: pick a wallpaper, tap **Preview transition** (works without locking), then **Set as live wallpaper**. Android's own preview screen appears and nothing changes until you confirm there. Choose **Both** (or **Home screen**; then set the same image as the lock-screen wallpaper in MIUI).

Watch the diagnostics (debug builds only; they compile to nothing in release):

```bash
adb logcat -c && adb logcat -s SubtleUnlock
# lock/unlock a few times; expect, per unlock, lines like:
#   screen off ... reset | visibility=true ... | unlock signal=USER_PRESENT ... | transition start ...
#   transition finished frames=~20 maxFrameGap=~16ms (no frames are scheduled now)
```

What to check: static while locked (no log activity at all while idle); one "transition start/finished" pair per unlock; `maxFrameGap` near the display frame time (about 16 ms at 60 Hz); no repeated rendering after "finished"; no crash lines. Memory and leaks:

```bash
adb shell dumpsys meminfo com.subtleunlock.wallpaper | head -30
adb logcat -b crash -d | tail
```

Lock/unlock without touching the phone (non-secure lock screen only; with a PIN, enter it yourself):

```bash
adb shell input keyevent 26      # power: screen off
adb shell input keyevent 26      # power: screen on
adb shell input swipe 540 2000 540 800   # swipe up to dismiss a swipe-lock
```

**If the effect never fires:** (1) check the log for `unlock signal=USER_PRESENT`; if it is missing, enable **Also trigger on wallpaper visibility** in the app; (2) set the app's MIUI battery saver to **No restrictions** and, if present, enable **Autostart**; (3) send me the log lines and your MIUI version and I will adjust the logic.

## 7. Uninstall and get your old wallpaper back

Android does **not** remember your previous wallpaper. Before applying, screenshot or note your current one.

* Switch back: Settings > Wallpaper (or the Themes/Wallpaper app) > choose your old wallpaper, for home and/or lock screen.
* Remove the app: `adb uninstall com.subtleunlock.wallpaper` (or long-press the app > Uninstall). If it was the active live wallpaper, Android falls back to the **system default wallpaper**, so re-select your own afterwards.
* No settings, services or system files were modified by this app.

## 8. Permissions, privacy, battery

* **Permissions: none.** No INTERNET, no storage (images come through the system file picker / Storage Access Framework and are copied privately), no location, no accessibility, no notification access, no device admin, no foreground service, no sensors.
* Nothing is transmitted; no analytics; no runtime downloads (wallpapers are bundled, generated by `tools/generate_wallpapers.py`).
* Idle cost: a few tiny system broadcasts per lock/unlock cycle (screen off, screen on, user present). No timers, no polling, no frame callbacks outside the ~0.3 s transition.
* No forced refresh rate; frames follow the display's normal Choreographer pacing.

## 9. Project layout

```
app/src/main/java/com/subtleunlock/wallpaper/
  UnlockWallpaperService.kt   service + engine, state machine, signals, drawing
  WallpaperRenderer.kt        decode-once bitmap, geometry, allocation-free draw
  TransitionRunner.kt         one-shot Choreographer clock + ease-out curve
  Wallpapers.kt               bundled samples, private-storage import
  Settings.kt                 settings model/defaults/persistence, debug log helper
  SettingsActivity.kt         dark settings UI (preview, picker, sliders, direction, reset)
  PreviewView.kt              in-app miniature preview using the same renderer
app/src/main/assets/wallpapers/   midnight_ridge.jpg, soft_aurora.jpg, alpine_dawn.jpg
tools/                        generate_wallpapers.py, static_checks.py, verify_geometry.py
```

## 10. Known limitations

* The fade/zoom MIUI shows on lock and unlock is System UI's. Wallpapers receive no signal for it, so it cannot be reproduced or changed here. This app adds its own separate movement instead.

* Cannot be frame-synchronised with, or alter, MIUI's native unlock animation.
* If your MIUI build refuses third-party live wallpapers on the lock screen, the lock screen keeps MIUI's static wallpaper; the motion still plays on the home screen after unlock.
* Which of home/lock an engine serves cannot be queried on Android 12; behaviour is decided per engine from signals and visibility.
* A wallpaper surface larger than the screen (some launchers request wide "scrolling" surfaces) would be cropped around its centre; the surface size is logged at start in debug builds.
* Not compile-tested or device-tested by the author (see section 1).
