#!/usr/bin/env python3
"""Checks the index maths of BlurUtil.boxBlur (a line-by-line port) against a naive clamp-and-average blur."""
import random

def clamp(i, m): return 0 if i < 0 else (m if i > m else i)

def box_blur_port(px, w, h, r):                      # port of BlurUtil.boxBlur on ONE channel
    win = 2 * r + 1
    tmp = [0] * (w * h)
    for y in range(h):
        row = y * w
        s = sum(px[row + clamp(i, w - 1)] for i in range(-r, r + 1))
        for x in range(w):
            tmp[row + x] = s // win
            s += px[row + clamp(x + r + 1, w - 1)] - px[row + clamp(x - r, w - 1)]
    out = [0] * (w * h)
    for x in range(w):
        s = sum(tmp[clamp(i, h - 1) * w + x] for i in range(-r, r + 1))
        for y in range(h):
            out[y * w + x] = s // win
            s += tmp[clamp(y + r + 1, h - 1) * w + x] - tmp[clamp(y - r, h - 1) * w + x]
    return out

def naive(px, w, h, r):                              # same integer rounding points, computed the slow obvious way
    win = 2 * r + 1
    tmp = [0] * (w * h)
    for y in range(h):
        for x in range(w):
            tmp[y * w + x] = sum(px[y * w + clamp(x + d, w - 1)] for d in range(-r, r + 1)) // win
    out = [0] * (w * h)
    for y in range(h):
        for x in range(w):
            out[y * w + x] = sum(tmp[clamp(y + d, h - 1) * w + x] for d in range(-r, r + 1)) // win
    return out

random.seed(3)
bad = 0
for (w, h, r) in [(1, 1, 1), (5, 3, 1), (7, 9, 2), (16, 11, 3), (4, 4, 6), (30, 20, 5)]:
    px = [random.randint(0, 255) for _ in range(w * h)]
    if box_blur_port(px, w, h, r) != naive(px, w, h, r):
        bad += 1; print("MISMATCH", w, h, r)
flat = [100] * 64
assert box_blur_port(flat, 8, 8, 2) == flat, "a flat image must stay flat"
print("box blur index maths:", "PASS" if bad == 0 else f"{bad} MISMATCH(ES)", "(6 shapes incl. radius > size, plus flat-image check)")

def factor_for(r):
    t = r / 3.0; f = 2
    while f < 16 and f * 1.4142 <= t: f *= 2
    return f
print("shrink factors for blur radius 4/12/20/40 px:", [factor_for(r) for r in (4, 12, 20, 40)])
