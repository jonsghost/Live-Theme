#!/usr/bin/env python3
"""
Cheap build-time sanity checks that need no Android SDK. They do NOT replace compiling:
bracket balance of Kotlin sources, XML well-formedness, resource/class/asset references.
Run from the project root:  python3 tools/static_checks.py
"""
import glob, os, re, sys
import xml.etree.ElementTree as ET

ROOT = os.path.join(os.path.dirname(__file__), "..")
os.chdir(ROOT)
problems = 0

def strip(src):
    # One pass, leftmost match wins: a string such as "image/*" is consumed as a string, never as a comment start.
    def repl(m):
        return '""' if m.group(0).startswith('"') else ''
    return re.sub(r'"(?:\\.|[^"\\\n])*"|/\*.*?\*/|//[^\n]*', repl, src, flags=re.S)

for f in sorted(glob.glob("app/src/main/java/**/*.kt", recursive=True)):
    t = strip(open(f).read())
    for a, b in ("()", "[]", "{}"):
        if t.count(a) != t.count(b):
            problems += 1; print("UNBALANCED", f, a, t.count(a), t.count(b))

for f in glob.glob("app/src/main/**/*.xml", recursive=True):
    try: ET.parse(f)
    except Exception as e: problems += 1; print("XML ERROR", f, e)

res = {"color": set(), "string": set()}
for fn, kind in (("colors.xml", "color"), ("strings.xml", "string")):
    for e in ET.parse("app/src/main/res/values/" + fn).getroot(): res[kind].add(e.get("name"))
for f in glob.glob("app/src/main/java/**/*.kt", recursive=True):
    for kind, name in re.findall(r'(?<!android\.)R\.(color|string)\.(\w+)', open(f).read()):
        if name not in res[kind]: problems += 1; print("MISSING resource", kind, name, "in", f)
for f in glob.glob("app/src/main/**/*.xml", recursive=True):
    for kind, name in re.findall(r'@(color|string)/(\w+)', open(f).read()):
        if name not in res[kind]: problems += 1; print("MISSING resource", kind, name, "in", f)

for must in ("app/src/main/res/drawable-nodpi/wallpaper_thumb.jpg",
             "app/src/main/res/drawable/ic_launcher_foreground.xml",
             "app/src/main/assets/wallpapers/midnight_ridge.jpg",
             "app/src/main/assets/wallpapers/soft_aurora.jpg",
             "app/src/main/assets/wallpapers/alpine_dawn.jpg"):
    if not os.path.exists(must): problems += 1; print("MISSING file", must)

src = {f: open(f).read() for f in glob.glob("app/src/main/java/**/*.kt", recursive=True)}
for cls in re.findall(r'android:name="\.(\w+)"', open("app/src/main/AndroidManifest.xml").read()):
    if not any(re.search(r'class\s+' + cls + r'\b', t) for t in src.values()):
        problems += 1; print("Manifest class not found:", cls)

for aid in re.findall(r'asset:([\w.]+)', src["app/src/main/java/com/subtleunlock/wallpaper/Wallpapers.kt"]):
    if not os.path.exists("app/src/main/assets/wallpapers/" + aid): problems += 1; print("Sample id without asset:", aid)

# there must be no permissions at all
manifest_no_comments = re.sub(r'<!--.*?-->', '', open("app/src/main/AndroidManifest.xml").read(), flags=re.S)
if "<uses-permission" in manifest_no_comments:
    problems += 1; print("Manifest declares a permission (none expected)")

print("static checks:", "PASS" if problems == 0 else f"{problems} PROBLEM(S)")
sys.exit(1 if problems else 0)
