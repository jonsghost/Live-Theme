#!/usr/bin/env python3
"""
Generates the three original sample wallpapers used by the app.

Everything is procedural (numpy + Pillow); no external images are used.
Output: 1440x3200 JPEG (20:9, matches the POCO M2 Pro's aspect and leaves
enough resolution for the app's motion margin).

Usage:  python3 tools/generate_wallpapers.py
"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W, H = 1440, 3200
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "wallpapers")
THUMB = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "drawable-nodpi", "wallpaper_thumb.jpg")


def hexrgb(s):
    s = s.lstrip("#")
    return np.array([int(s[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32)


def vgrad(stops, h=H, w=W):
    """Vertical gradient. stops = [(pos 0..1, '#rrggbb'), ...]"""
    ys = np.linspace(0, 1, h, dtype=np.float32)
    pos = [p for p, _ in stops]
    cols = np.stack([hexrgb(c) for _, c in stops])
    out = np.stack([np.interp(ys, pos, cols[:, ch]) for ch in range(3)], axis=-1)
    return np.repeat(out[:, None, :], w, axis=1)


def smooth_noise(n, scale, rng):
    """1-D smooth noise in [-1, 1] with feature size ~scale pixels."""
    k = max(2, int(n / scale) + 3)
    pts = rng.uniform(-1, 1, k).astype(np.float32)
    xs = np.linspace(0, k - 1, n, dtype=np.float32)
    # cosine interpolation for smoothness
    i0 = np.floor(xs).astype(int)
    t = xs - i0
    t = (1 - np.cos(t * np.pi)) / 2
    return pts[i0] * (1 - t) + pts[np.minimum(i0 + 1, k - 1)] * t


def ridge_profile(base_y, amp, rng, scales=(900, 380, 150, 60), weights=(1.0, 0.5, 0.22, 0.08)):
    p = np.zeros(W, dtype=np.float32)
    for s, wgt in zip(scales, weights):
        p += smooth_noise(W, s, rng) * wgt
    p = p / sum(weights)
    return base_y + p * amp


def coverage_below(profile):
    """Antialiased mask: 1 below the profile line."""
    ys = np.arange(H, dtype=np.float32)[:, None]
    return np.clip(ys - profile[None, :] + 0.5, 0.0, 1.0)


def composite(img, mask, color):
    m = mask[..., None]
    return img * (1 - m) + color * m


def add_grain(img, rng, sigma=1.1):
    noise = rng.normal(0, sigma, (H, W, 1)).astype(np.float32)
    return img + noise


def save(img, name, quality=90):
    arr = np.clip(img, 0, 255).astype(np.uint8)
    im = Image.fromarray(arr, "RGB")
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name)
    im.save(path, "JPEG", quality=quality, optimize=True, subsampling=0)
    print(f"wrote {os.path.normpath(path)}  {os.path.getsize(path)//1024} KB")
    return im


def radial(cx, cy, r, power=2.0):
    ys, xs = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2) / r
    return np.clip(1 - d, 0, 1) ** power


# --------------------------------------------------------------------------
# 1. Midnight Ridge: dark, minimal landscape
# --------------------------------------------------------------------------
def midnight_ridge():
    rng = np.random.default_rng(11)
    img = vgrad([(0.0, "#04060B"), (0.35, "#08111D"), (0.58, "#12263A"), (0.68, "#1D3A52"), (1.0, "#06090F")])

    # faint stars in the upper sky
    star = np.zeros((H, W), dtype=np.float32)
    for _ in range(170):
        x, y = rng.integers(0, W), int(rng.uniform(0, 0.50) * H)
        b = rng.uniform(0.25, 0.8)
        star[y, x] = max(star[y, x], b)
    star = np.array(Image.fromarray((star * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.1))) / 255.0 * 3.2
    img += np.clip(star, 0, 1)[..., None] * np.array([200, 215, 235], dtype=np.float32)

    # soft glow low on the horizon
    glow = radial(W * 0.68, H * 0.60, 900, 2.4)
    img += glow[..., None] * np.array([34, 70, 96], dtype=np.float32)

    layers = [
        (0.600, 120, "#1A3045", "#0F1E2E", 1),
        (0.655, 150, "#122436", "#0A1623", 2),
        (0.720, 130, "#0B1825", "#070E17", 3),
        (0.800, 100, "#070E16", "#04080D", 4),
    ]
    for base, amp, top, bottom, seed in layers:
        prof = ridge_profile(base * H, amp, np.random.default_rng(100 + seed))
        mask = coverage_below(prof)
        # vertical gradient inside the layer (lighter at the ridge, darker below)
        g = vgrad([(0.0, top), (1.0, bottom)])
        # keep the gradient anchored to the ridge band for a hazy look
        shift = int(base * H)
        g = np.roll(g, shift - H // 2, axis=0)
        img = composite(img, mask, g)

    img = add_grain(img, rng, 1.0)
    return save(img, "midnight_ridge.jpg")


# --------------------------------------------------------------------------
# 2. Soft Aurora: gradient / abstract
# --------------------------------------------------------------------------
def soft_aurora():
    rng = np.random.default_rng(23)
    img = vgrad([(0.0, "#141432"), (0.45, "#2A2352"), (1.0, "#3A2340")])

    blobs = [
        (0.15, 0.12, 1250, "#7B6CFF", 1.0),
        (0.90, 0.30, 1100, "#27C2C7", 0.85),
        (0.20, 0.55, 1300, "#E86FA3", 0.75),
        (0.85, 0.78, 1400, "#FF9C73", 0.85),
        (0.30, 0.95, 1200, "#FFC98F", 0.65),
    ]
    acc = np.zeros((H, W, 3), dtype=np.float32)
    wsum = np.zeros((H, W, 1), dtype=np.float32)
    for fx, fy, r, col, strength in blobs:
        a = (radial(fx * W, fy * H, r, 1.7) * strength)[..., None]
        acc += a * hexrgb(col)
        wsum += a
    cover = np.clip(wsum, 0, 1)
    blend = acc / np.maximum(wsum, 1e-4)
    img = img * (1 - cover * 0.88) + blend * cover * 0.88

    # a very soft diagonal light sweep to suggest silk
    ys, xs = np.mgrid[0:H, 0:W].astype(np.float32)
    wave = np.sin((xs * 0.0016 + ys * 0.0011) * 2 * np.pi * 0.9 + 0.6)
    img += (wave[..., None] * 5.5)

    img = add_grain(img, rng, 1.3)
    return save(img, "soft_aurora.jpg")


# --------------------------------------------------------------------------
# 3. Alpine Dawn: natural landscape with foreground / background depth
# --------------------------------------------------------------------------
def draw_tree(draw, cx, base, height, width, fill=255):
    tiers = 6
    for i in range(tiers):
        t0 = i / tiers
        y_top = base - height * (1 - t0 * 0.0) + height * (t0) * 0.86
        y_bot = y_top + height * 0.30
        half = width * (0.30 + 0.70 * (i + 1) / tiers) / 2
        draw.polygon([(cx, y_top), (cx - half, y_bot), (cx + half, y_bot)], fill=fill)
    draw.rectangle([cx - width * 0.035, base - height * 0.04, cx + width * 0.035, base + 6], fill=fill)


def alpine_dawn():
    rng = np.random.default_rng(37)
    img = vgrad([(0.0, "#23365C"), (0.22, "#4C5C8F"), (0.40, "#9C86AE"), (0.52, "#EDA68F"), (0.60, "#FBD7A6"), (1.0, "#FBD7A6")])

    # low sun + glow behind the far range
    sun_x, sun_y = W * 0.62, H * 0.545
    img += radial(sun_x, sun_y, 1000, 2.2)[..., None] * np.array([120, 70, 25], dtype=np.float32)
    img += radial(sun_x, sun_y, 190, 1.2)[..., None] * np.array([90, 70, 40], dtype=np.float32)

    def mist(strength, y0, y1):
        ys = np.linspace(0, 1, H, dtype=np.float32)
        band = np.clip(1 - np.abs((ys - (y0 + y1) / 2) / ((y1 - y0) / 2)), 0, 1) ** 1.6
        return (band * strength)[:, None, None]

    layers = [
        # base, amp, top color, bottom color, seed, mist after layer
        (0.560, 210, "#8C84B2", "#B99AB4", 5, (0.52, 0.55, 0.64)),
        (0.610, 190, "#6B70A0", "#9A86A6", 6, (0.50, 0.58, 0.68)),
        (0.670, 150, "#4A5C86", "#6F7396", 7, (0.50, 0.64, 0.74)),
        (0.735, 120, "#2F4668", "#46587B", 8, (0.40, 0.70, 0.80)),
    ]
    for base, amp, top, bottom, seed, (ms, m0, m1) in layers:
        prof = ridge_profile(base * H, amp, np.random.default_rng(200 + seed), scales=(1100, 430, 170, 70))
        mask = coverage_below(prof)
        g = vgrad([(0.0, top), (1.0, bottom)])
        g = np.roll(g, int(base * H) - H // 2, axis=0)
        img = composite(img, mask, g)
        mist_col = np.array([244, 214, 200], dtype=np.float32)
        img = img * (1 - mist(ms * 0.45, m0, m1)) + mist_col * mist(ms * 0.45, m0, m1)

    # foreground ridge + pines drawn at 2x for antialiasing, then downsampled
    scale = 2
    mask_big = Image.new("L", (W * scale, H * scale), 0)
    d = ImageDraw.Draw(mask_big)
    fg_prof = ridge_profile(0.835 * H, 110, np.random.default_rng(321), scales=(1000, 360, 140, 55))
    pts = [(x * scale, fg_prof[x] * scale) for x in range(W)]
    pts += [(W * scale, H * scale), (0, H * scale)]
    d.polygon(pts, fill=255)

    r2 = np.random.default_rng(77)
    x = -40
    while x < W + 60:
        cx = x + r2.uniform(-10, 10)
        gy = float(fg_prof[int(np.clip(cx, 0, W - 1))]) + 20
        hgt = r2.uniform(230, 520) * (1.0 + 0.5 * (gy / H - 0.83))
        wid = hgt * r2.uniform(0.34, 0.44)
        draw_tree(d, cx * scale, gy * scale, hgt * scale, wid * scale)
        x += r2.uniform(60, 130)
    # a few larger trees in the near-left and near-right corners for depth
    for cx, hgt in [(120, 900), (330, 640), (1290, 980), (1110, 700)]:
        gy = float(fg_prof[min(cx, W - 1)]) + 30
        draw_tree(d, cx * scale, gy * scale, hgt * scale, hgt * 0.40 * scale)
    fg_mask = np.array(mask_big.resize((W, H), Image.LANCZOS), dtype=np.float32) / 255.0

    fg_col = vgrad([(0.0, "#16223A"), (0.85, "#0D1626"), (1.0, "#070B14")])
    # lighter rim tone near the top of the foreground gives a hint of dawn light
    img = composite(img, fg_mask, fg_col)

    img = add_grain(img, rng, 1.0)
    return save(img, "alpine_dawn.jpg")


if __name__ == "__main__":
    a = midnight_ridge()
    b = soft_aurora()
    c = alpine_dawn()
    # thumbnail for the live-wallpaper picker (res/drawable-nodpi)
    os.makedirs(os.path.dirname(THUMB), exist_ok=True)
    c.resize((360, 800), Image.LANCZOS).save(THUMB, "JPEG", quality=86, optimize=True)
    print("wrote", os.path.normpath(THUMB))
